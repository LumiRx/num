// Invite sheet — sign up with a number, pick who you meant, send the invite
// from your own phone, and show the invitee how to keep Num on their home
// screen. Everything that turns one Num user into two happens here.
import { useEffect, useRef, useState } from 'react';
import { store, useApp } from '../../lib/store';
import { pressable, useDialogFocus } from '../../lib/a11y';
import { normalisePhone, describePhone } from '../../lib/phone';
import { sheetBase, grabberStyle } from '../../lib/derive';
import { CheckIcon, CopyIcon, ShareIcon, XIcon } from '../../lib/icons';
import { contactsSupported, mintInvite, pickContacts, resendCode, shareInvite, signUp, verifyCode, whoIsOnNum } from '../../lib/social';
import { canOfferInstall } from '../../lib/native';
import AppleSignIn from './AppleSignIn';

/** Matches RESEND_COOLDOWN_SEC in worker/social.mjs. Kept in step by hand;
 *  the client one only has to be >= the server's, since the server is the
 *  authority and a short client timer just earns a 429 with its own sentence. */
const RESEND_COOLDOWN_SEC = 60;

const isIOS = () => /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

const field: React.CSSProperties = {
  width: '100%', height: 44, borderRadius: 12, border: '1px solid var(--ink-12)',
  padding: '0 14px', fontSize: 16, background: 'var(--field-bg)', outline: 'none',
  fontFamily: 'var(--font-body)', color: 'var(--color-text)',
};
const primary: React.CSSProperties = {
  cursor: 'pointer', borderRadius: 999, background: 'var(--grad-accent)', color: '#fff',
  fontWeight: 700, fontSize: 12, letterSpacing: '.06em', padding: '12px 16px',
  display: 'flex', gap: 7, alignItems: 'center', justifyContent: 'center',
  boxShadow: '0 4px 14px rgba(236,48,19,.3)',
};
const label: React.CSSProperties = { fontSize: 10, letterSpacing: '.14em', color: 'var(--color-accent)', fontWeight: 700 };
const helpText: React.CSSProperties = { fontSize: 10.5, color: 'var(--color-neutral-500)', lineHeight: 1.55, marginTop: 10 };

/**
 * The install prompt.
 *
 * Two reasons this is big rather than a footnote:
 *
 *   · A PWA that lives in a browser tab is a PWA nobody opens twice. Installed,
 *     it is on the home screen next to everything else they use.
 *   · On iPhone, push notifications ONLY work for an installed app. Every
 *     "your table moved" Num will ever send depends on this one tap.
 *
 * The instructions differ per platform and getting them wrong is worse than
 * omitting them — an iPhone user told to look for "Install app" will hunt for
 * a menu item that does not exist.
 */
function AddToHomeScreen() {
  // canOfferInstall(), NOT a display-mode media query.
  //
  // `(display-mode: standalone)` is a PWA question, and the App Store build is
  // not a PWA — it is a WKWebView serving a bundle from capacitor://localhost,
  // where that query is false and `navigator.standalone` is undefined. So this
  // card, whose entire subject is "here is how to install Num", rendered
  // INSIDE the installed app. src/lib/native.ts was written on 15 Aug to fix
  // exactly this and canOfferInstall() is the answer it exports; this call
  // site was simply never moved over.
  //
  // Two things went wrong because of it, and the second is the one Andre saw:
  // it tells a TestFlight tester to go and install the app they are holding,
  // AND it adds roughly 200px directly above the sign-up button — on a screen
  // whose remaining height is already halved by the keyboard, that is the
  // difference between the button being reachable and the form looking broken.
  if (!canOfferInstall()) return null;

  const ios = /iPhone|iPad|iPod/.test(navigator.userAgent);

  return (
    <div
      style={{
        marginTop: 18,
        borderRadius: 'var(--r-lg)',
        padding: '18px 16px',
        background: 'var(--field-bg)',
        border: '1px solid var(--ink-12)',
        textAlign: 'center',
      }}
    >
      <div style={{ fontSize: 10, letterSpacing: '.16em', fontWeight: 800, color: 'var(--color-accent)' }}>PUT NUM ON YOUR PHONE</div>
      <div
        style={{
          fontFamily: 'var(--font-heading)',
          fontWeight: 800,
          fontSize: 26,
          lineHeight: 1.2,
          marginTop: 8,
          letterSpacing: '-.01em',
        }}
      >
        {ios ? 'Tap Share, then Add to Home Screen' : 'Tap the menu, then Add to Home Screen'}
      </div>
      <div style={{ fontSize: 12.5, color: 'var(--ink-60)', marginTop: 10, lineHeight: 1.55 }}>
        {ios
          ? 'The Share button is at the bottom of Safari — the square with an arrow coming out of it. Scroll down the list and pick “Add to Home Screen”.'
          : 'Open the ⋮ menu at the top right of Chrome and choose “Add to Home screen” or “Install app”.'}
      </div>
      <div style={{ fontSize: 11.5, color: 'var(--ink-40)', marginTop: 10, lineHeight: 1.5 }}>
        It opens full screen, remembers you, and it is the only way Num can reach you when a table moves or a friend replies.
      </div>
    </div>
  );
}

export default function InviteSheet() {
  const draft = useApp((s) => s.inviteOpen);
  const me = useApp((s) => s.me);
  const open = !!draft;
  const ref = useRef<HTMLDivElement>(null);
  useDialogFocus(open, ref);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [toName, setToName] = useState('');
  const [toPhone, setToPhone] = useState('');
  /** null = unknown / no number yet; true = they're already a member. */
  const [onNum, setOnNum] = useState<boolean | null>(null);
  const [code, setCode] = useState('');
  /**
   * The number a sign-in code was just sent to, or null.
   *
   * Non-null means we are on the SECOND outcome of `POST /api/social/me`:
   * this number already has an account, the server has texted it a code, and
   * it has deliberately told us NOTHING else — no member, no id (see the
   * three-outcome contract in `lib/social.ts`). So this screen has to stand on
   * its own: there is no `me` to hang a verify box off, which is why the box
   * below is not the one in the signed-in branch.
   */
  const [recoverPhone, setRecoverPhone] = useState<string | null>(null);
  // Null until we have heard from the server; false once it has told us there
  // is no SMS provider. Never assumed true — showing a verification step that
  // cannot work is the failure this replaces.
  const [smsOn, setSmsOn] = useState(false);
  // Two independent notices: one about the account/number, one about the
  // invite. Sharing a single `note` printed the SMS message under both.
  const [accountNote, setAccountNote] = useState<string | null>(null);
  const [inviteNote, setInviteNote] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState<'shared' | 'copied' | null>(null);
  /**
   * Seconds until "Send it again" is offered.
   *
   * Started at 60 the moment a code step appears, matching RESEND_COOLDOWN_SEC
   * on the server. Counting down here rather than only reacting to a 429 means
   * the button is never a control that exists solely to reject you — the wait
   * is visible, which is the difference between "not yet" and "broken".
   */
  const [resendIn, setResendIn] = useState(0);
  const [resendNote, setResendNote] = useState<string | null>(null);


  // Each time the sheet opens, seed the fields from whatever Num already
  // resolved — a name said in chat, a phone from a picked contact.
  useEffect(() => {
    if (!draft) return;
    setToName(draft.name ?? '');
    setToPhone(draft.phone ?? '');
    setSent(null);
    setInviteNote(null);
  }, [draft?.name, draft?.phone, !!draft]);

  if (!draft) return null;
  const close = () => store.set({ inviteOpen: null });

  // The button says what is missing rather than sitting dim and silent, so
  // nobody has to guess which field is the problem.
  //
  // THE NUMBER IS NO LONGER A WALL. 48 of our first 77 sign-ups typed a name
  // and stopped dead at this field — 62% of everyone who opened Num. A phone
  // number is worth a lot to us and nothing to someone who has not yet seen
  // the app work, so asking for it before any value is delivered trades most
  // of our funnel for it. Num now lets them in on a name and asks for the
  // number at the moment it actually buys them something (inviting a friend,
  // saving a plan, cashing out) — which is also the moment they will say yes.
  // What Num will actually text, shown BEFORE the tap — including the country
  // it guessed from the device. The one real campaign arrival who ever tried
  // to sign in typed an Indian mobile while in the UK, got +44 put on it, and
  // never received a code. He would have fixed it in a keystroke had he seen it.
  const phoneInfo = describePhone(phone);
  const phoneOk = !phone.trim() || (phoneInfo.ok && normalisePhone(phone) !== null);
  const ready = !!name.trim() && phoneOk;

  const doSignUp = async () => {
    // Never return silently. A button that looks tappable and does nothing is
    // read as a broken app, not as a validation failure — the person has no
    // way to know their name did not register, so they tap it again, and
    // again, and then leave.
    if (!name.trim()) {
      setAccountNote('I need a name first — just what you want to be called.');
      return;
    }
    // A number typed WRONG still stops here — a half-number is worse than
    // none, because it looks like we can reach them and we cannot. A number
    // left BLANK is fine: they are in, and Num asks again when it matters.
    const tidy = phone.trim() && phoneInfo.ok ? normalisePhone(phone) : null;
    if (phone.trim() && !tidy) {
      setAccountNote(phoneInfo.note ?? 'That number doesn’t look complete — or leave it blank and I’ll ask later.');
      return;
    }
    setAccountNote(null);
    setBusy(true);
    try {
      const out = await signUp(name.trim(), tidy ?? undefined);

      // OUTCOME 2 — the number is already on Num. Not an error, not a new
      // account: a sign-in that needs the code we just texted. Stay on this
      // sheet and swap it for the code step; closing it here would drop the
      // person into the app with no account and no idea a code was sent.
      if (out.outcome === 'code_sent') {
        setRecoverPhone(out.phone ?? tidy ?? null);
        setCode('');
        setResendIn(RESEND_COOLDOWN_SEC);
        setResendNote(null);
        setAccountNote(
          out.verification?.channel === 'review'
            ? 'Enter the sign-in code from App Store Connect.'
            // A throttled recovery is not a failed one: a code went out
            // moments ago and is still the code to type. The server's own
            // sentence says so better than a second version of it here.
            : out.verification?.sent === false && out.verification?.note
              ? out.verification.note
              : 'That number already has an account — I have texted it a six-digit code.',
        );
        return;
      }

      // OUTCOME 1 — a new account. Honest about what actually happened to the
      // number.
      setSmsOn(!!out.verification?.sent);
      setAccountNote(out.verification?.sent ? 'Code sent — type it in below.' : out.verification?.note ?? null);
      if (out.verification?.sent) { setResendIn(RESEND_COOLDOWN_SEC); setResendNote(null); }
      // Cold first run: they came to try the app, not to invite someone. Get
      // out of the way — Num picks the conversation up in the thread. When an
      // invite IS in flight, stay put and carry straight on to it.
      if (!sending) store.set({ inviteOpen: null, threadOpen: true });
    } catch (err) {
      setAccountNote(err instanceof Error ? err.message : 'That didn’t go through.');
    } finally {
      setBusy(false);
    }
  };

  /**
   * Tick the resend cooldown down to zero.
   *
   * One interval for the whole sheet, cleared on every change — a per-press
   * timer would keep running after the sheet closed and would leak one handle
   * per attempt on the exact screen people retry on most.
   */
  const cooling = resendIn > 0;
  useEffect(() => {
    if (!cooling) return undefined;
    const t = setInterval(() => setResendIn((n) => (n > 0 ? n - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, [cooling]);

  /**
   * "I didn't get it."
   *
   * The single most common thing that happens in phone verification, and until
   * now the app had no answer to it: the server has had a `/resend` route all
   * along and nothing ever called it.
   *
   * It reports what it actually knows. When Twilio has already resolved the
   * PREVIOUS code as undelivered, that is said out loud — because sending a
   * second code down a pipe that just dropped the first one, and announcing it
   * cheerfully, is how somebody ends up waiting twenty minutes for a text that
   * was never going to come.
   */
  const doResend = async () => {
    if (busy || resendIn > 0) return;
    setBusy(true);
    setResendNote(null);
    try {
      const out = await resendCode(recoverPhone ?? undefined);
      if (out.already) {
        setResendNote('That number is already verified — you are in.');
        return;
      }
      // Start the wait BEFORE reporting anything: the message was sent either
      // way, and a failed report must not hand back an uncooled button.
      setResendIn(RESEND_COOLDOWN_SEC);
      if (out.previous && out.previous.delivered === false) {
        setResendNote(
          `Sent again — but the last one never reached your carrier${out.previous.error_code ? ` (error ${out.previous.error_code})` : ''}. If this one does not arrive either, it is our end, not yours.`,
        );
        return;
      }
      setResendNote(out.sent ? 'New code on its way.' : 'I could not get a new code out just now. Give it a minute.');
    } catch (err) {
      // The server's throttle sentences are written for people. Passing them
      // through is the honest thing; inventing a cheerful one is not.
      setResendNote(err instanceof Error ? err.message : 'I could not get a new code out just now.');
    } finally {
      setBusy(false);
    }
  };

  const doVerify = async () => {
    if (code.trim().length < 4) {
      setAccountNote('Type the six digits from the text and I’ll check them.');
      return;
    }
    setBusy(true);
    try {
      // The number is passed only on the recovery path, where there is no
      // member id to present — that is what makes the server release the
      // account. `verifyCode` refuses to send both.
      const ok = await verifyCode(code.trim(), recoverPhone ?? undefined);
      if (ok && recoverPhone) {
        // `signUp` never ran on this device, so this is where the account
        // actually arrives. social.ts has already adopted it and closed the
        // sheet; all that is left is not to contradict it.
        setRecoverPhone(null);
        setAccountNote(null);
        return;
      }
      setAccountNote(ok ? 'Number verified.' : 'That code didn’t match.');
    } catch (err) {
      // The server's own sentence — "that code expired — ask for a new one",
      // "too many attempts" — is better than any guess we could make here.
      setAccountNote(err instanceof Error ? err.message : 'That code didn’t match.');
    } finally {
      setBusy(false);
    }
  };

  const doMint = async () => {
    if (!toName.trim() && !toPhone.trim()) return;
    setBusy(true);
    try {
      await mintInvite(toName.trim(), toPhone.trim() || undefined, draft.planId);
    } catch (err) {
      setInviteNote(err instanceof Error ? err.message : 'Couldn’t create that invite.');
    } finally {
      setBusy(false);
    }
  };

  // "Sending" means there is an actual invite in flight — a named person or a
  // plan to join. A cold first open is neither.
  const sending = !!(draft.name || draft.phone || draft.planId);
  const minted = draft.minted;
  const steps = minted ? (isIOS() ? minted.install_steps.ios : minted.install_steps.android) : [];

  return (
    <div
      ref={ref}
      className="glass-strong"
      style={{ ...sheetBase, visibility: open ? 'visible' : 'hidden', transform: open ? 'translateY(0)' : 'translateY(105%)', maxHeight: 'min(86%, calc(100% - var(--sat, 0px) - 8px))', overflowY: 'auto' }}
    >
      <div style={grabberStyle} />
      <div
        {...pressable(close)}
        aria-label="Close"
        className="glass press"
        style={{ position: 'absolute', top: 10, right: 10, width: 30, height: 30, borderRadius: 999, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', zIndex: 2 }}
      >
        <XIcon size={15} />
      </div>

      {/* 1 — you need an account before you can invite anyone. */}
      {!me ? (
        recoverPhone ? (
          /* 1b — this number already has an account. One code away from all of
             it. Deliberately its own screen: the verify box in the signed-in
             branch needs a `me`, and on this path there is not one yet. */
          <div style={{ padding: 16 }}>
            <div style={label}>WELCOME BACK</div>
            <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 800, fontSize: 19, marginTop: 6 }}>
              That number already has an account
            </div>
            <div style={{ fontSize: 12, color: 'var(--color-neutral-600)', marginTop: 5, lineHeight: 1.55 }}>
              Nothing is lost and nothing was started from scratch. I have sent a six-digit code to{' '}
              {recoverPhone.slice(-4).padStart(7, '•')} — type it in and your friends, plans and Stars come straight back.
            </div>
            <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
              <input
                style={{ ...field, flex: 1 }}
                placeholder="6-digit code"
                inputMode="numeric"
                value={code}
                onChange={(e) => setCode(e.target.value)}
              />
              <div {...pressable(doVerify)} style={{ ...primary, padding: '12px 18px', opacity: busy ? 0.5 : 1 }}>
                {busy ? '…' : 'CHECK'}
              </div>
            </div>
            {accountNote && <div style={{ ...helpText, color: 'var(--color-neutral-700)' }}>{accountNote}</div>}
            {/* "I didn't get it." Always present, never a dead control: it
                shows the wait rather than hiding until the wait is over, so
                nobody is left wondering whether asking again is even possible.
                A code that a carrier dropped is reported as such — see
                doResend. */}
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
              <span style={{ fontSize: 10.5, color: 'var(--color-neutral-500)' }}>Didn&rsquo;t get it?</span>
              {resendIn > 0 ? (
                <span style={{ fontSize: 10.5, color: 'var(--color-neutral-500)' }}>
                  You can ask again in {resendIn}s
                </span>
              ) : (
                <span
                  {...pressable(doResend)}
                  role="button"
                  aria-label="Send the code again"
                  style={{
                    fontSize: 10.5, fontWeight: 700, cursor: 'pointer', textDecoration: 'underline',
                    color: 'var(--color-neutral-700)', opacity: busy ? 0.5 : 1,
                  }}
                >
                  {busy ? 'Sending…' : 'Send it again'}
                </span>
              )}
            </div>
            {resendNote && <div style={{ ...helpText, marginTop: 6 }}>{resendNote}</div>}
            <div
              {...pressable(() => { setRecoverPhone(null); setCode(''); setAccountNote(null); setResendNote(null); })}
              style={{ ...helpText, cursor: 'pointer', textDecoration: 'underline' }}
            >
              That is not my number — go back
            </div>
          </div>
        ) : (
        <div style={{ padding: 16 }}>
          {/* First run and "I'm about to invite someone" are different moments
              and deserve different words — nothing is being sent on a cold open. */}
          {/* This is the first thing anyone is ASKED, and a form that reads
              like a signup form gets closed. Warm heading, one line of why,
              and a button that sounds like a person. */}
          <div style={label}>{sending ? 'YOUR NUM ACCOUNT' : 'HELLO'}</div>
          <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 800, fontSize: 19, marginTop: 6 }}>
            {sending ? 'Who am I sending this as?' : 'Let’s start with your name'}
          </div>
          <div style={{ fontSize: 12, color: 'var(--color-neutral-600)', marginTop: 5, lineHeight: 1.55 }}>
            {sending
              ? 'Your number is how friends find you and how invites carry your name. It is never shown to anyone you haven’t connected with.'
              : 'So I know what to call you. Your mobile is how friends find you here, and how I reach you if a booking moves — never shown to anyone you haven’t connected with.'}
          </div>
          {/* SIGN IN WITH APPLE, ON THE FIRST SCREEN — not buried in Profile.

              Two reasons, and the second is the one that cost a submission.

              1. Guideline 4.8 asks for the equivalent login option to be no
                 less prominent than the third-party one, and the first-run
                 screen is where an account actually begins.

              2. App Review's own screenshots of 1.0(2) show a reviewer who
                 typed the name "Qwerty", left the number blank, and landed in
                 an EMPTY account — no bookings, no people, no plans — while
                 our notes described a rich demo account they never reached.

              A blank number stays legal on purpose: making it mandatory would
              put every new user back behind the SMS path that has verified two
              people in this product's life. The fix is not a locked door, it
              is a better one — one tap, no code, no waiting for a text. */}
          <AppleSignIn onDone={close} />

          <div style={{ display: 'grid', gap: 10, marginTop: 14 }}>
            <input style={field} placeholder={sending ? 'Your name' : 'What should I call you?'} value={name} onChange={(e) => setName(e.target.value)} />
            <input style={field} placeholder={sending ? 'Their mobile' : 'Mobile (optional — for friends and bookings)'} inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
            {phone.trim() && phoneInfo.note && (
              <div style={{ fontSize: 12, lineHeight: 1.4, opacity: phoneInfo.ok ? 0.7 : 1, color: phoneInfo.ok ? undefined : '#c0392b' }}>
                {phoneInfo.note}
              </div>
            )}
            <div
              {...pressable(doSignUp)}
              aria-disabled={busy || !ready}
              style={{ ...primary, opacity: busy || !ready ? 0.5 : 1, cursor: busy ? 'wait' : 'pointer' }}
            >
              {busy
                ? 'ONE SEC…'
                : !name.trim()
                  ? 'YOUR NAME FIRST'
                  : !phoneOk
                    ? 'CHECK THAT NUMBER'
                    : sending
                      ? 'CREATE MY ACCOUNT'
                      : 'NICE TO MEET YOU'}
            </div>
          </div>
          {accountNote && <div style={{ ...helpText, color: 'var(--color-neutral-700)' }}>{accountNote}</div>}

          {/* Add to home screen. Deliberately large and above the fold on this
              screen, because it is the single step that decides whether Num is
              an app somebody has or a tab they lose. It only shows in a
              browser — once installed, telling someone to install is noise. */}
          <AddToHomeScreen />
        </div>
        )
      ) : (
        <>
          {/* 2 — verify the number, ONLY when SMS is actually switched on.
              It used to show unconditionally: a "6-digit code" box and a CHECK
              button for a code that is never sent, because there is no SMS
              provider. Dead controls are worse than missing ones — people wait
              for a text that will not arrive, then assume the app is broken
              rather than that the feature is not built. `smsOn` is set from
              the sign-up response, which says plainly whether a code went. */}
          {smsOn && !me.phone_verified && me.phone && (
            <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--ink-08)' }}>
              <div style={label}>VERIFY YOUR NUMBER</div>
              <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
                <input style={{ ...field, flex: 1 }} placeholder="6-digit code" inputMode="numeric" value={code} onChange={(e) => setCode(e.target.value)} />
                <div {...pressable(doVerify)} style={{ ...primary, padding: '12px 18px' }}>CHECK</div>
              </div>
              {accountNote && <div style={helpText}>{accountNote}</div>}
            {/* "I didn't get it." Always present, never a dead control: it
                      shows the wait rather than hiding until the wait is over, so
                      nobody is left wondering whether asking again is even possible.
                      A code that a carrier dropped is reported as such — see
                      doResend. */}
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
                  <span style={{ fontSize: 10.5, color: 'var(--color-neutral-500)' }}>Didn&rsquo;t get it?</span>
                  {resendIn > 0 ? (
                      <span style={{ fontSize: 10.5, color: 'var(--color-neutral-500)' }}>
                        You can ask again in {resendIn}s
                      </span>
                  ) : (
                      <span
                        {...pressable(doResend)}
                        role="button"
                        aria-label="Send the code again"
                        style={{
                          fontSize: 10.5, fontWeight: 700, cursor: 'pointer', textDecoration: 'underline',
                          color: 'var(--color-neutral-700)', opacity: busy ? 0.5 : 1,
                        }}
                      >
                        {busy ? 'Sending…' : 'Send it again'}
                      </span>
                  )}
              </div>
              {resendNote && <div style={{ ...helpText, marginTop: 6 }}>{resendNote}</div>}
            </div>
          )}

          {/* 3 — who is this going to? */}
          {!minted ? (
            <div style={{ padding: 16 }}>
              <div style={label}>{draft.planId ? 'INVITE TO THE PLAN' : 'INVITE A FRIEND'}</div>
              <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 800, fontSize: 18, marginTop: 6 }}>
                {draft.name ? `Send ${draft.name} an invite` : 'Who are we bringing in?'}
              </div>

              {!!draft.candidates?.length && (
                <>
                  <div style={{ fontSize: 11.5, color: 'var(--color-neutral-600)', marginTop: 6 }}>
                    I found {draft.candidates.length === 1 ? 'one match' : `${draft.candidates.length} matches`} — tap the right one so it goes to the right person.
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 }}>
                    {draft.candidates.map((c) => (
                      <div
                        key={c.name + (c.phone ?? '')}
                        {...pressable(() => { setToName(c.name); setToPhone(c.phone ?? ''); })}
                        className="glass lift"
                        style={{ cursor: 'pointer', borderRadius: 999, padding: '8px 13px', fontSize: 11.5, fontWeight: 600, display: 'flex', gap: 6, alignItems: 'center' }}
                      >
                        {toName === c.name && <CheckIcon size={12} />} {c.name}
                        {c.phone && <span style={{ opacity: 0.5 }}>· {c.phone.slice(-4).padStart(6, '•')}</span>}
                      </div>
                    ))}
                  </div>
                </>
              )}

              <div style={{ display: 'grid', gap: 10, marginTop: 14 }}>
                <input style={field} placeholder="Their name" value={toName} onChange={(e) => setToName(e.target.value)} />
                <input
                  style={field}
                  placeholder="Their mobile number (optional)"
                  inputMode="tel"
                  value={toPhone}
                  onChange={(e) => setToPhone(e.target.value)}
                  onBlur={() => {
                    // The moment a plausible number is in the box, find out if
                    // they're already one of us — it changes what the invite
                    // means (instant connect vs "text them the link").
                    const p = toPhone.replace(/[^0-9+]/g, '');
                    if (p.length >= 7) void whoIsOnNum([p]).then((m) => setOnNum(m.get(p) ?? null));
                    else setOnNum(null);
                  }}
                />
                {onNum !== null && (
                  <div
                    style={{
                      fontSize: 11.5, fontWeight: 600, borderRadius: 10, padding: '8px 12px', lineHeight: 1.45,
                      background: onNum ? 'rgba(22,140,90,.12)' : 'rgba(236,48,19,.08)',
                      color: onNum ? '#0e6b45' : 'var(--color-accent-700)',
                    }}
                  >
                    {onNum
                      ? '✓ Already on Num — your invite connects you two instantly, no download needed.'
                      : 'Not on Num yet — create the invite and text it to them; the link sets them up.'}
                  </div>
                )}
                {contactsSupported() && (
                  <div
                    {...pressable(async () => {
                      const picked = await pickContacts();
                      if (picked[0]) {
                        setToName(picked[0].name);
                        setToPhone(picked[0].phone ?? '');
                        const p = (picked[0].phone ?? '').replace(/[^0-9+]/g, '');
                        if (p.length >= 7) void whoIsOnNum([p]).then((m) => setOnNum(m.get(p) ?? null));
                      }
                    })}
                    className="glass press"
                    style={{ cursor: 'pointer', borderRadius: 999, padding: '11px 16px', fontSize: 12, fontWeight: 700, letterSpacing: '.06em', textAlign: 'center' }}
                  >
                    PICK FROM CONTACTS
                  </div>
                )}
                <div {...pressable(doMint)} style={{ ...primary, opacity: busy || (!toName.trim() && !toPhone.trim()) ? 0.6 : 1 }}>
                  {busy ? 'ONE SEC…' : 'CREATE THE INVITE'}
                </div>
              </div>
              <div style={helpText}>
                {contactsSupported()
                  ? 'The picker only ever returns the person you tap — Num never reads your address book.'
                  : 'This browser has no contacts API, so type the name. Nothing is read from your phone.'}
              </div>
              {inviteNote && <div style={{ ...helpText, color: 'var(--color-accent-700)' }}>{inviteNote}</div>}
            </div>
          ) : (minted as { on_num?: boolean }).on_num ? (
            /* 4a — they're already on Num: the agents handled it. The plan is
               in their app and their phone buzzed. No text message needed —
               offering one anyway would make delivery look like it failed. */
            <div style={{ padding: 16 }}>
              <div style={label}>DELIVERED</div>
              <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 800, fontSize: 18, marginTop: 6 }}>
                ✓ Sent app to app{draft.name ? ` — ${draft.name} has it` : ''}
              </div>
              <div style={{ fontSize: 12.5, color: 'var(--color-neutral-600)', lineHeight: 1.55, marginTop: 8 }}>
                They’re already on Num, so your Num told theirs directly: the {draft.planId ? 'plan is in their PLAN tab' : 'connection is live'} and their phone just buzzed. Nothing to text, nothing to tap.
              </div>
              <div
                {...pressable(() => store.set({ inviteOpen: null }))}
                style={{ marginTop: 14, cursor: 'pointer', borderRadius: 999, background: 'var(--grad-accent)', color: '#fff', fontWeight: 700, fontSize: 12, letterSpacing: '.06em', padding: '12px 16px', textAlign: 'center' }}
              >
                DONE
              </div>
              <div style={{ fontSize: 10.5, color: 'var(--color-neutral-500)', marginTop: 10, lineHeight: 1.5 }}>
                Want to nudge them yourself anyway? The link still works: {minted.link}
              </div>
            </div>
          ) : (
            /* 4 — ready to send, from the member's own phone. */
            <div style={{ padding: 16 }}>
              <div style={label}>READY TO SEND</div>
              <div style={{ fontFamily: 'var(--font-heading)', fontWeight: 800, fontSize: 18, marginTop: 6 }}>
                {draft.name ? `${draft.name}’s invite is ready` : 'Your invite is ready'}
              </div>
              <div style={{ marginTop: 10, padding: 12, borderRadius: 'var(--r-md)', background: 'var(--field-bg)', border: '1px solid var(--ink-08)', fontSize: 12, lineHeight: 1.5, color: 'var(--ink)' }}>
                {minted.message}
              </div>

              <div style={{ display: 'grid', gap: 8, marginTop: 12 }}>
                <div {...pressable(async () => setSent(((await shareInvite()) === 'shared' ? 'shared' : 'copied')))} style={primary}>
                  <ShareIcon size={14} /> {sent === 'shared' ? 'SENT' : sent === 'copied' ? 'COPIED — PASTE IT TO THEM' : 'SEND IT'}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                  <a href={minted.sms_url} className="glass press" style={{ flex: 1, textAlign: 'center', textDecoration: 'none', color: 'var(--ink)', borderRadius: 999, padding: '11px 12px', fontSize: 11.5, fontWeight: 700, letterSpacing: '.06em' }}>
                    TEXT IT
                  </a>
                  <a href={minted.whatsapp_url} target="_blank" rel="noreferrer" className="glass press" style={{ flex: 1, textAlign: 'center', textDecoration: 'none', color: 'var(--ink)', borderRadius: 999, padding: '11px 12px', fontSize: 11.5, fontWeight: 700, letterSpacing: '.06em' }}>
                    WHATSAPP
                  </a>
                  <div
                    {...pressable(() => { void navigator.clipboard?.writeText(minted.link); setSent('copied'); })}
                    className="glass press"
                    style={{ cursor: 'pointer', borderRadius: 999, padding: '11px 14px', display: 'flex', alignItems: 'center' }}
                    aria-label="Copy link"
                  >
                    <CopyIcon size={14} />
                  </div>
                </div>
              </div>

              {/* The part people actually forget: keeping it on the home screen. */}
              <div style={{ marginTop: 16, padding: 13, borderRadius: 'var(--r-md)', background: 'var(--field-bg)', border: '1px solid var(--ink-08)' }}>
                <div style={{ ...label, color: 'var(--ink-60)' }}>WHAT THEY’LL DO — {isIOS() ? 'IPHONE' : 'ANDROID'}</div>
                <ol style={{ margin: '8px 0 0', paddingLeft: 18, fontSize: 11.5, lineHeight: 1.7, color: 'var(--color-neutral-700)' }}>
                  {steps.map((s) => (
                    <li key={s}>{s}</li>
                  ))}
                </ol>
                <div style={{ ...helpText, marginTop: 8 }}>
                  Their invite carries your referral code, so the moment they join it counts to you — and the two Nums connect on their own.
                </div>
              </div>

              <div
                {...pressable(() => store.set((s) => ({ inviteOpen: { planId: s.inviteOpen?.planId ?? null } })))}
                style={{ marginTop: 14, fontSize: 11, fontWeight: 700, letterSpacing: '.08em', color: 'var(--color-accent-700)', cursor: 'pointer' }}
              >
                INVITE SOMEONE ELSE
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
