// YOUR PEOPLE — and the way out.
//
// Removing someone is a two-tap action behind a per-row disclosure, never a
// button sitting next to a name. An accidental unfriend is not recoverable by
// the person who did it: they have to ask to be re-added, which is the exact
// conversation they were trying to avoid.
//
// The block checkbox is offered at the moment of removal because that is the
// only moment the distinction is live in someone's head. Buried in settings it
// would be found by nobody who needed it.
import { useState } from 'react';
import { useApp } from '../../lib/store';
import { pressable } from '../../lib/a11y';
import { unfriend } from '../../lib/social';
import { UsersIcon } from '../../lib/icons';
import ReportSheet from './ReportSheet';

const card: React.CSSProperties = { margin: '10px 12px', borderRadius: 'var(--r-lg)', padding: 14 };
const kicker: React.CSSProperties = { fontSize: 10, letterSpacing: '.14em', fontWeight: 800, color: 'var(--ink-40)' };

export default function PeopleCard() {
  // Select the RAW array and filter below.
  //
  // useApp is useSyncExternalStore: the selector IS getSnapshot, and React
  // compares snapshots by reference. A selector ending in .filter() returns a
  // fresh array on every read, so React sees a change every time, re-renders,
  // reads again — "Maximum update depth exceeded", and a blank screen. It
  // crashed this whole tab before a browser pass caught it; the build and the
  // types were both perfectly happy.
  const all = useApp((s) => s.friends);
  const friends = all.filter((f) => f.state === 'active' && !!f.id);
  const [openId, setOpenId] = useState<string | null>(null);
  const [block, setBlock] = useState(false);
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<string | null>(null);
  // Guideline 1.2 again: reporting has to be reachable from the person, not
  // only from a conversation. Someone may never have opened a DM and still
  // need to report a profile name, bio or avatar.
  const [reporting, setReporting] = useState<{ id: string; name?: string | null } | null>(null);

  if (!friends.length) return null;

  const remove = async (id: string) => {
    setBusy(true);
    const msg = await unfriend(id, block);
    setBusy(false);
    setOpenId(null);
    setBlock(false);
    setNote(msg);
    setTimeout(() => setNote(null), 4000);
  };

  return (
    <div className="glass" style={card}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
        <UsersIcon size={13} style={{ color: 'var(--ink-40)' }} />
        <div style={kicker}>YOUR PEOPLE</div>
        <div style={{ marginLeft: 'auto', fontSize: 10.5, color: 'var(--ink-40)' }}>{friends.length}</div>
      </div>

      <div style={{ marginTop: 10, display: 'grid', gap: 2 }}>
        {friends.map((f) => {
          const open = openId === f.id;
          return (
            <div key={f.id ?? f.name ?? Math.random()} style={{ borderRadius: 12, background: open ? 'var(--field-bg)' : 'transparent', padding: open ? 10 : 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: open ? 0 : '7px 0' }}>
                <div
                  style={{
                    width: 30, height: 30, borderRadius: 999, flex: 'none', background: 'var(--grad-accent)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: '#fff', fontWeight: 800, fontSize: 13, fontFamily: 'var(--font-heading)',
                  }}
                >
                  {f.name?.[0]?.toUpperCase() ?? '?'}
                </div>
                <div style={{ flex: 1, minWidth: 0, fontSize: 13, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {f.name ?? 'Someone'}
                </div>
                <div
                  {...pressable(() => { setOpenId(open ? null : f.id ?? null); setBlock(false); })}
                  aria-label={open ? 'Close' : `Options for ${f.name ?? 'this person'}`}
                  style={{ cursor: 'pointer', fontSize: 15, letterSpacing: 1, color: 'var(--ink-40)', padding: '0 4px' }}
                >
                  {open ? '×' : '···'}
                </div>
              </div>

              {open && (
                <div style={{ marginTop: 10 }}>
                  <label style={{ display: 'flex', gap: 8, alignItems: 'flex-start', cursor: 'pointer', fontSize: 11, color: 'var(--ink-60)', lineHeight: 1.5 }}>
                    <input
                      type="checkbox"
                      checked={block}
                      onChange={(e) => setBlock(e.target.checked)}
                      style={{ marginTop: 2, accentColor: 'var(--color-accent)' }}
                    />
                    <span>
                      <b style={{ color: 'var(--ink)' }}>Also block them.</b> Without this they can add you
                      straight back — by link or by scanning your code.
                    </span>
                  </label>
                  <div
                    {...pressable(() => { if (!busy && f.id) void remove(f.id); })}
                    style={{
                      cursor: 'pointer', marginTop: 10, borderRadius: 999, padding: '10px 14px', textAlign: 'center',
                      border: '1.5px solid rgba(190,40,30,.35)', color: '#a3271c',
                      fontWeight: 800, fontSize: 11, letterSpacing: '.06em', opacity: busy ? 0.5 : 1,
                    }}
                  >
                    {busy ? 'REMOVING…' : block ? 'REMOVE AND BLOCK' : 'REMOVE'}
                  </div>
                  {/* Said plainly so nobody removes someone expecting it to
                      land as a message. */}
                  <div style={{ fontSize: 10, color: 'var(--ink-40)', marginTop: 7, lineHeight: 1.45, textAlign: 'center' }}>
                    They aren’t told.
                  </div>
                  {/* Removing is a preference; reporting says a human should
                      look. Kept visually quieter than REMOVE so the common
                      action stays the obvious one. */}
                  <div
                    {...pressable(() => { if (f.id) setReporting({ id: f.id, name: f.name }); })}
                    style={{
                      cursor: 'pointer', marginTop: 10, textAlign: 'center',
                      fontSize: 11, color: 'var(--ink-60)', textDecoration: 'underline',
                    }}
                  >
                    Report {f.name || 'this person'}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {reporting && (
        <ReportSheet
          id={reporting.id}
          name={reporting.name}
          context="people"
          onClose={() => { setReporting(null); setOpenId(null); }}
        />
      )}

      {note && (
        <div style={{ marginTop: 10, fontSize: 11.5, color: 'var(--ink-60)', lineHeight: 1.5 }}>{note}</div>
      )}
    </div>
  );
}
