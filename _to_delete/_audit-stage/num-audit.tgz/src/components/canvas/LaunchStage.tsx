// What a desktop visitor sees. Phones (<720px) get the real app — see
// useStandalone() in App.tsx — so this page's only job is to convince someone
// at a laptop and then get Num onto their phone.
// (The internal prototype canvas — poster, demo script, release notes — is
// still available at ?canvas.)
//
// ── WHY THIS WAS REBUILT ──────────────────────────────────────────────────
//
// The previous version centred two 852px-tall phone frames inside a container
// with `overflow: hidden` and `justifyContent: center`. On any laptop shorter
// than the frames, they were clipped at the fold, the page could not scroll to
// reveal them, and there was no button anywhere — the only call to action was
// a line of grey footer text. A visitor from a paid ad landed on a poster of
// the product with no way into it and no way down the page.
//
// Three rules now hold:
//
//   · THE PAGE SCROLLS. No `overflow: hidden` on a container whose children
//     are taller than a laptop viewport. That one property was the bug.
//   · THERE IS A BUTTON ABOVE THE MOCKUPS. Someone who has already decided
//     should never have to scroll past a screenshot to act.
//   · THE DESKTOP → PHONE HANDOFF IS EXPLICIT. Num lives on a phone home
//     screen; a laptop visitor needs telling how to get it there.
import { useCallback, useEffect, useState } from 'react';
import { isNativeApp, escapeCard } from '../../lib/native';
import IOSDevice from '../device/IOSDevice';
import ConciergeApp from '../app/ConciergeApp';
import LockScreen from './LockScreen';
import { MessageIcon, RouteIcon, WalletIcon } from '../../lib/icons';
import type { IconProps } from '../../lib/icons';
import { PairHandoff } from '../app/PairBridge';
import InstallPrompt from '../app/InstallPrompt';

/**
 * Viewport width AND height.
 *
 * Height matters here as much as width: the phone mockup is 852px tall at full
 * size, which is taller than a 13-inch laptop viewport, so a width-only sizing
 * rule let the mockup swallow the whole first screen.
 */
function useViewport(): { width: number; height: number } {
  const [vp, setVp] = useState(() => ({ width: window.innerWidth, height: window.innerHeight }));
  useEffect(() => {
    const onResize = () => setVp({ width: window.innerWidth, height: window.innerHeight });
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  return vp;
}

const PROMISES: Array<[label: string, Icon: (p?: IconProps) => JSX.Element]> = [
  ['Ask in plain words', MessageIcon],
  ['It books and reshuffles', RouteIcon],
  ['Settle in one tap', WalletIcon],
];

/**
 * The same five promises as the /watch/ landing page, word for word.
 *
 * Deliberately duplicated rather than paraphrased: two pages that ad traffic
 * can land on must make the identical promise, or the product a visitor was
 * sold depends on which link they happened to click.
 */
const FEATURES: Array<[emoji: string, title: string, body: string]> = [
  ['🍴', 'Ask in plain words', '“Dinner for four tonight, somewhere with a view” — Num finds it, checks it, books it.'],
  ['🚗', 'Cars that actually turn up', 'Airport pickups, drivers for the day, a ride home at 2am — sorted from one message.'],
  ['👥', 'Plan together', 'Pull your friends in. Everyone sees the plan, nobody retypes an address, the group decides once.'],
  ['⭐', 'Split anything', 'Open a tab for the night out. Everyone pays for exactly what they were in on.'],
  ['🔔', 'It thinks ahead', 'Rain coming before your beach day? A table to reconfirm? Num tells you before you ask.'],
];

/**
 * Install steps, matched to the device actually reading them.
 *
 * Same wording as InstallPrompt.tsx — a visitor who sees the floating prompt
 * and then reads this section must not be given two different sets of
 * instructions for the same three taps.
 */
type Platform = 'ios' | 'android' | 'desktop';
const detectPlatform = (): Platform => {
  const ua = navigator.userAgent;
  if (/iPad|iPhone|iPod/.test(ua)) return 'ios';
  if (/Android/.test(ua)) return 'android';
  return 'desktop';
};
const INSTALL: Record<Platform, { heading: string; steps: string[] }> = {
  ios: {
    heading: 'Add Num to your home screen',
    steps: ['Tap the Share button at the bottom of Safari', 'Choose “Add to Home Screen”', 'Tap Add — Num opens like any other app'],
  },
  android: {
    heading: 'Add Num to your home screen',
    steps: ['Tap the ⋮ menu in Chrome', 'Choose “Install app” or “Add to Home screen”', 'Confirm — Num opens like any other app'],
  },
  desktop: {
    heading: 'Put Num on your phone',
    steps: [
      'Open app.itsnum.com in your phone’s browser',
      'Tap Share (iPhone) or the ⋮ menu (Android), then “Add to Home Screen”',
      'Open it from your home screen — it behaves like any other app',
    ],
  },
};

/**
 * The numbers, and only the ones we have actually earned.
 *
 * A landing page is where borrowed proof gets invented — "50,000 happy
 * travellers", five gold stars, a wall of stock-photo faces. Num has 77 members
 * and two onboarded venues, so any of that would be a lie told to someone who
 * is about to trust us with their evening. What IS true is the scale of the
 * directory and the fact that the free tier is the whole product, so that is
 * what this says, with the early-access caveat stated rather than buried.
 */
const STATS: Array<[figure: string, label: string]> = [
  ['2.5M+', 'places indexed and searchable'],
  ['77', 'destinations live today'],
  ['Free', 'the whole concierge, not a trial'],
];

/**
 * What people ask before they will type anything.
 *
 * This is the section the page was missing. A visitor from a cold ad has five
 * or six real objections — is this free, do I have to install something, will
 * it work where I'm going, what happens to what I tell it — and a page that
 * answers none of them asks for trust it has not earned. Every answer here is
 * checkable against the product: the free tier, the 12-month erasure, the
 * refusal to store sensitive detail and the honest decline for uncovered
 * cities are all real behaviour, not copy.
 */
const FAQ: Array<[q: string, a: string]> = [
  ['Is it free?',
    'Yes. The free tier is the whole concierge, not a demo of one — asking, planning and booking all work without paying us anything. If you book something that costs money, you pay the venue as you normally would.'],
  ['Do I have to download an app?',
    'No. Num runs in your browser and you can start right now. Adding it to your home screen takes about ten seconds and makes it open full screen, keep your thread and notify you when a booking is confirmed. There is no App Store step today.'],
  ['Will it work where I am going?',
    '77 destinations are live and the directory holds over 2.5 million places, deepest across Thailand. Ask about somewhere we do not cover properly and Num says so plainly instead of inventing a recommendation — that is a deliberate rule, not a gap we are hiding.'],
  ['Do I need an account?',
    'No. Open it and start typing. You only give a phone number or email if you want your thread on more than one device, or want us to reach you about a booking.'],
  ['What happens to what I tell it?',
    'Num keeps a short profile of your preferences so it never asks twice. It deliberately does not store health conditions, religion, politics, ID or payment details even if you mention them. Text FORGET and it is erased; profiles unused for 12 months are deleted automatically.'],
  ['Is it a bot or real people?',
    'Both, honestly. The concierge answers you directly and real bookings go to real venues who confirm them. If something cannot be arranged you are told — you will not be left holding a confirmation that reached nobody.'],
];

const NAV: Array<[label: string, href: string]> = [
  ['How it works', 'https://itsnum.com/how-it-works/'],
  ['Perks', 'https://itsnum.com/perks/'],
  ['For business', 'https://itsnum.com/business/'],
];

/**
 * Keep whatever brought them here.
 *
 * Campaign tags arrive in the URL and lib/social.ts captures them on first
 * load, but in-page links must carry them too — otherwise a visitor who clicks
 * through and later returns arrives untagged. Cheap to preserve, impossible to
 * reconstruct afterwards.
 */
function withSearch(path: string): string {
  const qs = window.location.search;
  if (!qs) return path;
  return path + (path.includes('?') ? '&' + qs.slice(1) : qs);
}

/**
 * One tap where the platform allows it, honest instructions where it doesn't.
 *
 * Android/Chrome: the shell captured beforeinstallprompt into
 * window.__numInstall — calling prompt() opens the NATIVE install sheet, and
 * "add to home screen" becomes literally one tap plus Add. That sheet can be
 * shown once per captured event, so the reference is cleared after use.
 *
 * iOS Safari: Apple exposes NO API for this — no site can open the Add to
 * Home Screen sheet, which is why the instruction overlay exists at all.
 * Falling back to it is not a bug; it is the entire iOS story.
 */
function useNativeInstall() {
  const [ready, setReady] = useState<boolean>(() => Boolean((window as any).__numInstall));
  useEffect(() => {
    const on = () => setReady(true);
    const off = () => setReady(false);
    window.addEventListener('num-installable', on);
    window.addEventListener('num-installed', off);
    return () => { window.removeEventListener('num-installable', on); window.removeEventListener('num-installed', off); };
  }, []);
  const promptInstall = useCallback(async () => {
    const e = (window as any).__numInstall;
    if (!e) return false;
    (window as any).__numInstall = null;
    setReady(false);
    try {
      e.prompt();
      const choice = await e.userChoice;
      return choice?.outcome === 'accepted';
    } catch {
      return false;
    }
  }, []);
  return { ready, promptInstall };
}

export default function LaunchStage() {
  const { width, height } = useViewport();
  const showLock = width >= 1180;
  // Below this the two frames stop fitting side by side; one honestly-sized
  // frame beats two clipped ones.
  // Sized against the VIEWPORT HEIGHT as well as the width. A 393×852 frame is
  // taller than most laptop viewports on its own, so the mockup filled the
  // screen, pushed every word below it off-screen, and left a slab of empty
  // space beside it on the way down. Capping at 62vh keeps the phone a
  // showcase rather than the whole page.
  const frameW = Math.min(width < 900 ? 320 : 372, Math.round((height * 0.62) / (852 / 393)));
  const frameH = Math.round(frameW * (852 / 393));
  // Read once on mount: the platform cannot change mid-visit, and calling
  // navigator during render would make this component non-deterministic.
  const [platform] = useState(detectPlatform);
  // Inside an in-app browser the per-platform steps below are wrong — they
  // name Safari's Share menu and Chrome's ⋮ menu, and a web view has neither.
  // The escape card supplies the steps that ARE possible from in there, and
  // this section swaps to them so the page and the floating prompt cannot
  // give one person two different answers.
  const escape = escapeCard();
  const install = escape
    ? { heading: escape.heading, steps: escape.steps }
    : INSTALL[platform];
  const onPhone = platform !== 'desktop';
  // The app-store build never shows the landing page: someone who installed
  // from a store did not come to be marketed to. ConciergeApp is the app.
  useEffect(() => {
    if (isNativeApp() && !location.search.includes('app=1')) {
      location.replace('/?app=1');
    }
  }, []);
  const { ready: nativeInstall, promptInstall } = useNativeInstall();

  // ── Asking to install is an ACTION, not a scroll ────────────────────────
  //
  // Both install buttons used to be `href="#on-your-phone"`, so tapping the
  // primary call to action moved the page down to a small grey card. That is
  // not what the button says it does, and on the one device where we CAN open
  // the real OS install sheet we were declining to.
  //
  // Now: fire the platform's own prompt where one exists, and everywhere else
  // open a sheet that states the steps at a size someone can follow while
  // holding the phone. The anchor stays as the href so a middle-click, a
  // no-JS visitor and the keyboard all still reach the instructions.
  const [showSteps, setShowSteps] = useState(false);
  const startInstall = (e: React.MouseEvent) => {
    e.preventDefault();
    if (nativeInstall) { void promptInstall(); return; }
    setShowSteps(true);
  };

  return (
    <div
      style={{
        minHeight: '100vh',
        position: 'relative',
        // NOT hidden. The children are taller than most laptop viewports and
        // hiding the overflow is what turned this page into a dead end.
        overflowX: 'clip',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 28,
        padding: '44px 24px 72px',
        fontFamily: 'var(--font-body)',
        color: 'var(--ink)',
      }}
    >
      <div className="aurora-layer" aria-hidden="true" />
      <InstallPrompt />

      {/* The install steps, as a sheet you cannot miss.
          Replaces scrolling someone to a small card at the foot of the page.
          Big type on purpose: this is read once, at arm's length, while the
          reader is holding the phone they are trying to change. */}
      {showSteps && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={install.heading}
          onClick={() => setShowSteps(false)}
          style={{
            position: 'fixed', inset: 0, zIndex: 200, display: 'flex',
            alignItems: 'center', justifyContent: 'center', padding: 20,
            background: 'rgba(24,16,12,.55)', backdropFilter: 'blur(6px)',
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              background: 'var(--paper, #fffaf7)', borderRadius: 26, padding: '30px 28px 26px',
              maxWidth: 460, width: '100%', boxShadow: '0 30px 80px rgba(0,0,0,.35)',
              textAlign: 'left',
            }}
          >
            <h2
              style={{
                fontFamily: 'var(--font-heading)', fontWeight: 800,
                fontSize: 'clamp(23px, 5vw, 30px)', letterSpacing: '-.02em',
                margin: '0 0 18px', lineHeight: 1.15,
              }}
            >
              {install.heading}
            </h2>
            <ol style={{ margin: 0, padding: 0, listStyle: 'none', display: 'grid', gap: 14 }}>
              {install.steps.map((s: string, i: number) => (
                <li key={s} style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
                  <span
                    aria-hidden="true"
                    style={{
                      flex: 'none', width: 32, height: 32, borderRadius: 999,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      background: 'linear-gradient(135deg,#ff6a3d,#ec3013)', color: '#fff',
                      fontWeight: 800, fontSize: 15,
                    }}
                  >
                    {i + 1}
                  </span>
                  <span style={{ fontSize: 18, fontWeight: 600, lineHeight: 1.42, paddingTop: 3 }}>{s}</span>
                </li>
              ))}
            </ol>
            <button
              type="button"
              onClick={() => setShowSteps(false)}
              style={{
                marginTop: 24, width: '100%', border: 0, cursor: 'pointer',
                borderRadius: 999, padding: '15px 20px', fontWeight: 800, fontSize: 16,
                background: 'var(--ink)', color: 'var(--paper, #fff)',
              }}
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {/* Navigation. The old page had none: someone who landed here from an ad
          and wanted to know who we are had no way out except the back button,
          which on a paid click means leaving. */}
      <nav
        style={{
          position: 'relative', zIndex: 2, width: '100%', maxWidth: 1040,
          display: 'flex', alignItems: 'center', gap: 18, flexWrap: 'wrap',
          marginBottom: 6, fontSize: 14,
        }}
      >
        <a
          href="https://itsnum.com/"
          style={{ display: 'inline-flex', alignItems: 'center', gap: 8, textDecoration: 'none', color: 'var(--ink)', fontWeight: 700 }}
        >
          <span style={{ width: 9, height: 9, borderRadius: 3, background: 'var(--color-accent)' }} aria-hidden="true" />
          NUM <span style={{ fontWeight: 500, fontSize: 12, color: 'var(--ink-40)' }}>travel concierge</span>
        </a>
        <span style={{ marginLeft: 'auto', display: 'flex', gap: 18, flexWrap: 'wrap' }}>
          {NAV.map(([label, href]) => (
            <a key={label} href={href} style={{ textDecoration: 'none', color: 'var(--ink-60)', fontWeight: 500 }}>
              {label}
            </a>
          ))}
        </span>
      </nav>

      {/* A friend link opened in the browser instead of the app. Show the code
          to carry across, above everything — it is why they are here. */}
      <div style={{ position: 'relative', zIndex: 2, width: '100%', maxWidth: 420 }}>
        <PairHandoff />
      </div>

      <header style={{ position: 'relative', zIndex: 1, textAlign: 'center', maxWidth: 780 }}>
        <span
          style={{
            display: 'inline-block', fontFamily: 'var(--font-mono, monospace)', fontSize: 11.5,
            fontWeight: 700, letterSpacing: '.16em', textTransform: 'uppercase',
            color: 'var(--color-accent)', marginBottom: 14,
          }}
        >
          Early access · live in 77 destinations
        </span>

        {/* The one line the whole page rests on.
            clamp() rather than a fixed size: this has to read as a headline on
            a 1440px laptop AND on a 360px phone, and a fixed 44px was neither.
            Concrete over clever — "a table, a car, a whole day" is what people
            actually ask for, and naming it does more work than an adjective. */}
        <h1
          style={{
            fontFamily: 'var(--font-heading)', fontWeight: 800,
            fontSize: 'clamp(38px, 6.2vw, 68px)', letterSpacing: '-.03em',
            margin: 0, lineHeight: 1.02,
          }}
        >
          Ask for anything.
          <br />
          <span style={{ color: 'var(--color-accent)' }}>Num sorts it.</span>
        </h1>

        <p style={{ fontSize: 'clamp(16px, 1.7vw, 19px)', color: 'var(--ink-60)', margin: '18px auto 0', lineHeight: 1.55, maxWidth: 560 }}>
          Dinner tonight, a driver at six, a whole weekend for eight. Text it in plain
          words and your concierge handles the rest — no forms, no phone calls,
          no forty browser tabs.
        </p>

        {/* The primary action depends on the device, because "add to your home
            screen" is impossible advice on a laptop and the most valuable thing
            a phone visitor can do. Getting this backwards is how a landing page
            asks people for something they cannot give. */}
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap', marginTop: 30 }}>
          {onPhone ? (
            <>
              <a
                href="#on-your-phone"
                onClick={startInstall}
                style={{
                  display: 'inline-block', textDecoration: 'none', borderRadius: 999,
                  padding: '17px 34px', fontWeight: 700, fontSize: 17, color: '#fff',
                  background: 'linear-gradient(135deg,#ff6a3d,#ec3013)',
                  boxShadow: '0 12px 30px rgba(236,48,19,.38)',
                }}
              >
                {nativeInstall ? 'Add Num to my home screen — one tap' : 'Add Num to my home screen'}
              </a>
              <a
                href={withSearch('/?app=1')}
                className="glass"
                style={{
                  display: 'inline-block', textDecoration: 'none', borderRadius: 999,
                  padding: '17px 28px', fontWeight: 600, fontSize: 16, color: 'var(--ink)',
                }}
              >
                Try it first
              </a>
            </>
          ) : (
            <>
              <a
                href={withSearch('/?app=1')}
                style={{
                  display: 'inline-block', textDecoration: 'none', borderRadius: 999,
                  padding: '17px 34px', fontWeight: 700, fontSize: 17, color: '#fff',
                  background: 'linear-gradient(135deg,#ff6a3d,#ec3013)',
                  boxShadow: '0 12px 30px rgba(236,48,19,.38)',
                }}
              >
                Open Num
              </a>
              <a
                href="#on-your-phone"
                onClick={startInstall}
                className="glass"
                style={{
                  display: 'inline-block', textDecoration: 'none', borderRadius: 999,
                  padding: '17px 28px', fontWeight: 600, fontSize: 16, color: 'var(--ink)',
                }}
              >
                Put it on my phone
              </a>
            </>
          )}
        </div>
        <p style={{ fontSize: 13.5, color: 'var(--ink-40)', margin: '14px 0 0' }}>
          Free · no app store · about ten seconds to set up
        </p>

        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', justifyContent: 'center', marginTop: 22 }}>
          {PROMISES.map(([label, Icon]) => (
            <span
              key={label}
              className="glass"
              style={{ display: 'inline-flex', alignItems: 'center', gap: 7, borderRadius: 999, padding: '7px 14px', fontSize: 12, fontWeight: 600 }}
            >
              <Icon size={13} style={{ color: 'var(--color-accent)' }} />
              {label}
            </span>
          ))}
        </div>
      </header>

      {/* Live product, not a screenshot — the left frame is the real
          ConciergeApp and answers for real. */}
      {/* SCROLL, NOT CAPTURE.
          These frames contain the real ConciergeApp, which has its own
          scrollable thread — and they sit dead centre of the viewport, exactly
          where a cursor lands. With pointer events live, the wheel scrolled the
          app inside the frame and the page appeared frozen; three separate
          "the page won't scroll" reports were all this, not the CSS.
          The frames are a showcase here: the way in is the Open Num button, so
          they are inert and the wheel always belongs to the page. */}
      <div
        style={{
          position: 'relative', zIndex: 1, display: 'flex', gap: 40,
          alignItems: 'flex-start', justifyContent: 'center', flexWrap: 'wrap',
          pointerEvents: 'none', userSelect: 'none',
        }}
        aria-hidden="true"
      >
        <IOSDevice width={frameW} height={frameH}>
          <ConciergeApp />
        </IOSDevice>
        {showLock && (
          <IOSDevice width={frameW} height={frameH} dark>
            <LockScreen />
          </IOSDevice>
        )}
      </div>

      {/* What it actually does. Below the phone on purpose: the mockup earns
          the attention, the words tell you what you are looking at. */}
      <section style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: 900 }}>
        <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 22, letterSpacing: '-.015em', textAlign: 'center', margin: '0 0 20px' }}>
          What Num does
        </h2>
        <div style={{ display: 'grid', gap: 14, gridTemplateColumns: 'repeat(auto-fit,minmax(270px,1fr))' }}>
          {FEATURES.map(([emoji, title, body]) => (
            <div
              key={title}
              className="glass"
              style={{ display: 'flex', gap: 14, alignItems: 'flex-start', borderRadius: 18, padding: '16px 18px' }}
            >
              <span
                aria-hidden="true"
                style={{
                  flex: 'none', width: 38, height: 38, borderRadius: 12, fontSize: 18,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: 'linear-gradient(135deg,#ffe9e2,#ffd9cd)',
                }}
              >
                {emoji}
              </span>
              <span>
                <b style={{ display: 'block', fontSize: 15, marginBottom: 3 }}>{title}</b>
                <span style={{ fontSize: 13.5, color: 'var(--ink-60)', lineHeight: 1.55 }}>{body}</span>
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Scale, stated honestly. Sits between "what it does" and "how to get
          it" because that is where the question "is this real?" actually
          arrives — after they understand the offer, before they commit. */}
      <section style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: 900 }}>
        <div
          className="glass"
          style={{
            borderRadius: 20, padding: '24px 22px', display: 'grid', gap: 18,
            gridTemplateColumns: 'repeat(auto-fit,minmax(190px,1fr))', textAlign: 'center',
          }}
        >
          {STATS.map(([figure, label]) => (
            <div key={label}>
              <b style={{ fontFamily: 'var(--font-heading)', fontSize: 30, letterSpacing: '-.03em', display: 'block', lineHeight: 1 }}>
                {figure}
              </b>
              <span style={{ fontSize: 13, color: 'var(--ink-60)', display: 'block', marginTop: 7 }}>{label}</span>
            </div>
          ))}
        </div>
        <p style={{ fontSize: 12.5, color: 'var(--ink-40)', textAlign: 'center', margin: '14px auto 0', maxWidth: 620, lineHeight: 1.6 }}>
          Those are the real figures from our own directory. Num is in early access — we would
          rather tell you exactly what it can do today than borrow numbers we have not earned.
        </p>
      </section>

      {/* The objections, answered. The page shipped without this and it is the
          single biggest reason a cold visitor leaves: not disagreement, just
          unanswered questions they were never going to email us about.
          <details> rather than a JS accordion — it is keyboard accessible,
          works before hydration, and cannot break. */}
      <section style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: 720 }}>
        <h2 style={{ fontFamily: 'var(--font-heading)', fontSize: 22, letterSpacing: '-.015em', textAlign: 'center', margin: '0 0 20px' }}>
          Straight answers
        </h2>
        {FAQ.map(([q, a]) => (
          <details
            key={q}
            className="glass"
            style={{ borderRadius: 16, padding: '15px 18px', marginBottom: 10 }}
          >
            <summary style={{ cursor: 'pointer', fontWeight: 700, fontSize: 15.5, listStyle: 'none' }}>
              {q}
            </summary>
            <p style={{ fontSize: 14, color: 'var(--ink-60)', lineHeight: 1.65, margin: '10px 0 0' }}>{a}</p>
          </details>
        ))}
      </section>

      {/* The handoff. Num is a home-screen app; the steps differ per device and
          giving an iPhone user Android instructions is the same as giving them
          none. Wording matches InstallPrompt.tsx so the floating prompt and
          this section never disagree. */}
      <section
        id="on-your-phone"
        className="glass"
        style={{
          position: 'relative', zIndex: 1, maxWidth: 620, width: '100%',
          borderRadius: 26, padding: '34px 32px 30px', textAlign: 'left', scrollMarginTop: 24,
        }}
      >
        {/* Sized to be read, not skimmed past. This is the last thing on the
            page and the single action the whole page is asking for; at 18px
            with 14.5px grey steps it read as a footnote to its own headline. */}
        <h2
          style={{
            fontFamily: 'var(--font-heading)', fontWeight: 800,
            fontSize: 'clamp(24px, 3.4vw, 34px)', margin: '0 0 20px',
            letterSpacing: '-.02em', lineHeight: 1.12,
          }}
        >
          {install.heading}
        </h2>
        <ol style={{ margin: 0, padding: 0, listStyle: 'none', display: 'grid', gap: 16 }}>
          {install.steps.map((s: string, i: number) => (
            <li key={s} style={{ display: 'flex', gap: 15, alignItems: 'flex-start' }}>
              <span
                aria-hidden="true"
                style={{
                  flex: 'none', width: 34, height: 34, borderRadius: 999,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  background: 'linear-gradient(135deg,#ff6a3d,#ec3013)', color: '#fff',
                  fontWeight: 800, fontSize: 16,
                }}
              >
                {i + 1}
              </span>
              <span style={{ fontSize: 'clamp(17px, 2vw, 19px)', fontWeight: 600, lineHeight: 1.45, paddingTop: 4 }}>
                {s}
              </span>
            </li>
          ))}
        </ol>
        <p style={{ fontSize: 14, color: 'var(--ink-40)', margin: '20px 0 0', lineHeight: 1.6 }}>
          No app store, nothing to download. Num is a website that keeps your thread,
          so it works the moment you open it — adding it to your home screen just
          makes it open like an app.
        </p>
      </section>

      <footer
        style={{
          position: 'relative', zIndex: 1, fontSize: 12.5, color: 'var(--ink-40)',
          textAlign: 'center', display: 'flex', gap: 16, flexWrap: 'wrap', justifyContent: 'center',
        }}
      >
        <a href="https://itsnum.com/" style={{ color: 'inherit' }}>itsnum.com</a>
        <a href="https://itsnum.com/how-it-works/" style={{ color: 'inherit' }}>How it works</a>
        <a href="https://itsnum.com/business/" style={{ color: 'inherit' }}>For business</a>
        <a href="https://itsnum.com/privacy/" style={{ color: 'inherit' }}>Privacy</a>
        <a href="https://itsnum.com/terms/" style={{ color: 'inherit' }}>Terms</a>
        <span>NUM by 5arz</span>
      </footer>
    </div>
  );
}
