// The social seam: who you are, who you're connected to, and the plan a group
// builds together. Talks to /api/social/* (worker/social.mjs).
//
// The one rule that makes agent-to-agent sharing safe: nothing crosses between
// two people until BOTH acted — you by sending the invite, them by opening it
// on their own device. Until then a link is 'pending' and carries nothing.
import { store } from './store';
import { anonId } from './anon';
import { refreshRequests } from './requests';
import { refreshStars } from './stars';
import { resumeDm } from './dm';
import { askNum } from './concierge';
import { track } from './track';
import type { Friend, InviteDraft, Member, PartyPlan, PlanItem, Booking } from './types';
import { apiUrl } from '../lib/apibase';
import { isNativeApp } from './native';

const CLAIM = 'https://num-claim.thatislumi.workers.dev';

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  // The address is worked out once and then named in every diagnostic below.
  // The entire class of failure this file has already survived is "the app
  // asked the wrong place", and a log that does not say WHERE it asked cannot
  // tell you that. It costs one variable.
  const url = apiUrl('/api/social') + path;
  let res: Response;
  try {
    res = await fetch(url, {
      ...init,
      headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
    });
  } catch (err) {
    // Nothing answered at all: offline, DNS, TLS, or a shell pointed at an
    // origin that does not exist. Safari rejects this with "Load failed",
    // which names nothing at all, so we say the address out loud instead.
    console.warn('[social] no response', { url, origin: window.location.origin, err });
    throw new Error(`Couldn't reach Num — nothing answered at ${url}. Check your connection and try again.`);
  }
  // NOT `.catch(() => ({}))`.
  //
  // That swallow is what turned a network misconfiguration into
  // `undefined is not an object (evaluating 'r.mr.name')` on the first
  // TestFlight build. The native shell resolved a relative /api path against
  // its own bundle, the SPA fallback returned index.html with status 200,
  // JSON.parse threw, the catch produced `{}`, and `signUp` then read
  // `out.me.name` on undefined — two frames and one screen away from the
  // actual cause, with a message naming a minified variable.
  //
  // A response that is not JSON is a failure. Saying so here costs one line
  // and saves an evening.
  //
  // The body is read as TEXT first so that when it is not JSON we can still
  // show what it was. `res.json()` throws away the thing you most need to see.
  const raw = await res.text();
  let body: unknown;
  try {
    body = JSON.parse(raw);
  } catch {
    // Three facts identify this in one glance: the address we used, the origin
    // we used it FROM — `capacitor://localhost` is the whole bug — and the
    // first line of what came back, which on the TestFlight build was
    // `<!doctype html>`.
    console.warn('[social] not JSON', {
      url,
      origin: window.location.origin,
      status: res.status,
      contentType: res.headers.get('content-type'),
      head: raw.slice(0, 120),
    });
    throw new Error(
      res.ok
        ? "Couldn't reach Num — the server answered with something unexpected. That is the app asking the wrong address, not anything you did; the console has the address it used."
        : `social ${res.status}`,
    );
  }
  if (!res.ok) {
    // The server writes these sentences for people — "That number is already
    // on Num, and I can't text a code to it right now. Message us and we'll
    // get you back in." — so they pass through untouched. Rewording them here
    // would leave two versions of one message to keep in step, and the one the
    // user sees would be the one nobody edits.
    const said = (body as { error?: string }).error;
    console.warn('[social] error', { url, status: res.status, body });
    throw new Error(said || `Num couldn't finish that one (${res.status}). Try again in a moment.`);
  }
  return body as T;
}

/** Stable per-device id — minted once, kept even if the profile is cleared. */
function deviceId(): string {
  let id = localStorage.getItem('num-device-id');
  if (!id) {
    id = 'mem_' + (crypto.randomUUID?.() ?? String(Date.now())).replace(/-/g, '').slice(0, 20);
    localStorage.setItem('num-device-id', id);
  }
  return id;
}

// ── boot ───────────────────────────────────────────────────────────────────

/**
 * Read the referral/invite off the launch URL and hydrate anything we already
 * belong to. Runs once, on app start.
 */
export function bootSocial(): void {
  const q = new URLSearchParams(window.location.search);

  // ── Ad attribution, first touch only ────────────────────────────────────
  //
  // The UTM on the FIRST open is the ad that brought this person; a later
  // visit via a different link must not overwrite it, or every campaign's
  // numbers bleed into whichever ad they clicked most recently. Captured
  // before history.replaceState below scrubs the URL.
  if (q.get('utm_source') && !localStorage.getItem('num-utm')) {
    try {
      localStorage.setItem('num-utm', JSON.stringify({
        source: q.get('utm_source')?.slice(0, 60),
        medium: q.get('utm_medium')?.slice(0, 60),
        campaign: q.get('utm_campaign')?.slice(0, 80),
      }));
    } catch { /* private mode — attribution is not worth breaking boot */ }
  }
  const ref = q.get('ref');
  const token = q.get('i');

  // A scanned pay code. The phone's own camera opened this URL, so by the time
  // we are here the "scanner" has already done its job.
  const payTo = q.get('p');
  if (payTo) {
    store.set({
      payOpen: { to: payTo, amount: Number(q.get('a')) || undefined, note: q.get('n') ?? undefined },
    });
    history.replaceState(null, '', window.location.pathname);
    // Put a name to the code: "Pay them" is not a confirmation.
    void fetch(apiUrl(`/api/social/who?id=${encodeURIComponent(payTo)}`))
      .then((r) => (r.ok ? r.json() : null))
      .then((w) => {
        if (w?.name) store.set((st) => ({ payOpen: st.payOpen ? { ...st.payOpen, toName: w.name } : st.payOpen }));
      })
      .catch(() => {});
  }

  // A scanned "connect with me" code. This is the whole point of the QR: the
  // sharer offered, the scanner accepted, so the connection is made now rather
  // than turned into a request somebody has to remember to approve.
  const connectTo = q.get('c');

  if (ref || token || connectTo) {
    store.set((s) => ({
      refCode: ref ?? s.refCode,
      inviteToken: token ?? s.inviteToken,
      connectTo: connectTo ?? s.connectTo,
    }));
    // Keep the launch URL clean so a refresh doesn't re-trigger the invite.
    history.replaceState(null, '', window.location.pathname);
  }

  // ── Share target: anything, from any app, straight into the thread ──────
  //
  // A concierge is most useful at the moment you see the thing — a friend
  // sends a restaurant link, you spot a hotel, someone forwards an event. The
  // manifest registers Num in the OS share sheet, so that moment costs one tap
  // instead of copy → switch app → paste. The shared text becomes a question.
  const shared = [q.get('share_title'), q.get('share_text'), q.get('share_url')]
    .filter(Boolean).join(' ').trim();
  if (shared) {
    history.replaceState(null, '', window.location.pathname);
    store.set({ threadOpen: true, view: 'thread' });
    // Deferred so the app has mounted and the store is live before it answers.
    setTimeout(() => { void askNum(`Someone shared this with me — what do you make of it? ${shared}`); }, 400);
  }

  // ── Home-screen shortcuts (long-press the icon) ─────────────────────────
  const go = q.get('go');
  if (go === 'thread') store.set({ threadOpen: true, view: 'thread' });
  else if (go === 'plan') store.set({ view: 'plan', threadOpen: false });
  else if (go === 'wallet') store.set({ walletOpen: true, threadOpen: false });
  if (go) history.replaceState(null, '', window.location.pathname);

  // ── The Safari ↔ installed-app wall ─────────────────────────────────────
  //
  // On iOS the home-screen app and Safari keep SEPARATE storage, so each has
  // its own member id. A friend link tapped in Messages opens Safari — and
  // accepting it there bound the friendship to a Safari identity the person's
  // real app can never see. That is why friends "went to my Safari Num".
  //
  // So when a connect or invite arrives OUTSIDE the installed app, we do not
  // consume it. We park it server-side and show a short code to carry across.
  // Refusing to act is the correct behaviour here: acting would silently do
  // the wrong thing, which is worse than asking for one more tap.
  // isNativeApp() is the third arm, and it is not optional. The App Store
  // build is a WKWebView on capacitor://localhost — not a PWA — so BOTH of
  // the checks above are false inside it. Without this arm the installed iOS
  // app treats itself as "a Safari tab", refuses to accept the invite that
  // opened it, and shows a carry-across pair code to somebody who is already
  // exactly where the code was going to send them.
  const installed =
    isNativeApp() ||
    window.matchMedia('(display-mode: standalone)').matches ||
    (navigator as Navigator & { standalone?: boolean }).standalone === true;

  if (!installed && (connectTo || token)) {
    void fetch(apiUrl('/api/social/pair/mint'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(connectTo ? { connect_to: connectTo } : { token }),
    })
      .then((r) => r.json())
      .then((d: { code?: string }) => {
        if (d.code) store.set({ pairCode: d.code, connectTo: null, inviteToken: null });
      })
      .catch(() => {});
    return;
  }

  const me = store.get().me;
  if (me) {
    // Someone who already has an account must never be pushed back through
    // sign-up by opening an invite. They are already themselves; the link only
    // adds a friend or a plan to what they have.
    if (connectTo) void connectByCode(connectTo);
    if (token) void acceptInvite(token);
    void refreshFriends();
    void refreshPlans();
    void syncPlan();
    void refreshRequests();
    void refreshStars();
    return;
  }

  // No account on this device. EVERY first open asks for a name and a number —
  // not just invited ones. Without them Num has no way to connect this person
  // to anybody, and a demo that ends with an anonymous device is a demo we
  // cannot follow up on.
  // The cold-start welcome already ends with "Let's start with your name", so
  // adding another line here asks twice — which reads like the app was not
  // listening to itself. Only the invited path needs its own framing.
  store.set((s) => ({
    msgs:
      token || ref
        ? [
            ...s.msgs,
            {
              who: 'c' as const,
              text: 'Someone you know sent you here, which saves me the sales pitch.\n\nShort version: you ask for things — a table, a car, a whole weekend — and I sort them out. And since your friend is already here, once you’re set up our two sides talk directly. Plans just land; nobody retypes an address.\n\nLet’s start with your name.',
            },
          ]
        : s.msgs,
    chips: [{ id: 'signup', label: 'Tell Num who I am' }],
  }));
  // Put the form in front of them rather than hoping they tap the chip. It
  // lands after the first paint so the app is visibly there behind it.
  setTimeout(() => {
    if (!store.get().me && !store.get().inviteOpen) store.set({ threadOpen: true, inviteOpen: {} });
  }, 900);
}

// ── identity ───────────────────────────────────────────────────────────────

/**
 * THE THREE-OUTCOME CONTRACT for `POST /api/social/me`.
 *
 * Written out here, in full, because getting it wrong is not a cosmetic bug:
 * it is the first screen of the app refusing to let anybody past it.
 *
 *   200  { me, ref, link, verification }        A NEW number. The account
 *                                               exists and its id is in hand.
 *
 *   202  { recovery: 'code_sent', phone,        An EXISTING number. There is
 *          verification, next }                 NO member and NO id in this
 *                                               body, deliberately — see
 *                                               below. The right screen is
 *                                               "enter the code", and the
 *                                               identity arrives from
 *                                               POST /verify { phone, code }.
 *
 *   4xx/5xx { error: '<a whole sentence>' }     A real failure. 409 the number
 *                                               is verified on another device,
 *                                               503 the code could not be
 *                                               texted (A2P 10DLC, today),
 *                                               400 a name or country code is
 *                                               missing. `api()` above throws
 *                                               the server's sentence as-is.
 *
 * WHY THE 202 CARRIES NO ID. `worker/social.mjs` used to hand the whole
 * account back to whoever typed the number — no code, no text to the owner,
 * and the id it returned is the credential on every other route (Stars, DMs,
 * payment history, deletion). That is SEC-001 × SEC-006, and the fix is that
 * an unverified number is a CLAIM until a code proves it. So anything
 * bearer-shaped in the 202 would be the hole reopened.
 *
 * The cost of a client that does not know this: `signUp()` used to throw
 * "Couldn't finish signing you up" whenever `me.id` was absent, so the moment
 * the server fix deploys EVERY returning number — Andre's, the App Review
 * demo account's, every one of the 125 members reinstalling — hits a hard
 * error on the first screen. That is what this file now handles.
 *
 * Server side, verbatim: `worker/social.mjs` `me()` (the `holder` branch) and
 * `verifyMe()`. Written up in `HQ/divisions/num/SEC-001_REMEDIATION.md` §3 and
 * `HQ/divisions/num/APP_REVIEW_RECOVERY.md` §3.
 */
interface Verification {
  sent: boolean;
  reason?: string;
  note?: string;
  /** Refused by the cooldown, not by a provider — a code is already in flight. */
  throttled?: boolean;
  retry_after_sec?: number;
  /** 'sms' normally; 'review' for the App Store Connect grant. */
  channel?: string;
  expires_in_min?: number;
}

interface MeResponse {
  me: Member;
  ref: string;
  link: string;
  verification: Verification | null;
}

/** The 202. No `me`, no `id`, no `ref`, no `link` — by design, not by omission. */
interface RecoveryResponse {
  recovery: 'code_sent';
  recovered?: boolean;
  phone?: string;
  verification: Verification | null;
  next?: string;
}

/**
 * Which of the two GOOD outcomes happened. Failures throw, with a sentence.
 *
 * A discriminated union rather than an optional `me`, so that a caller cannot
 * quietly read `.me` on the recovery answer and get `undefined` — which is the
 * exact shape of the bug this replaces.
 */
export type SignUpResult =
  | { outcome: 'account'; me: Member; ref: string; link: string; verification: Verification | null }
  | { outcome: 'code_sent'; phone: string | null; verification: Verification | null };

/**
 * The number we are in the middle of recovering.
 *
 * Recovery is the one flow where the client has NO member id to present —
 * that is the entire point of the server fix — so the number has to survive
 * the hop from `signUp()` to `verifyCode()`. Module state rather than store
 * state because it is not part of a saved identity: it is a pending proof,
 * and if the app is reloaded halfway the right thing is to ask for the number
 * again rather than to resume something nobody re-typed.
 */
let recoveringPhone: string | null = null;

/** The number a code was sent to, if a code screen should be up. */
export function pendingRecovery(): string | null {
  return recoveringPhone;
}

/**
 * Take on an identity the server has just released, and put the app into the
 * state a signed-in device is in.
 *
 * Shared by recovery and by the App Review grant, because "we now know who
 * this is" has exactly one correct set of consequences and having two copies
 * of them is how one of them goes stale.
 */
function adoptMember(m: Member): void {
  store.set((s) => ({
    me: m,
    chips: s.chips.filter((c) => c.id !== 'signup'),
    // The sheet has done its job. Leaving it up after a successful sign-in
    // reads as if the code was not accepted.
    inviteOpen: null,
    threadOpen: true,
    msgs: [
      ...s.msgs,
      {
        who: 'c' as const,
        text: `Welcome back, ${m.name ?? 'you'}. That is your own account — nothing was started from scratch, and your friends, plans and Stars are all where you left them.`,
      },
    ],
  }));
  void refreshFriends();
  void refreshPlans();
  void syncPlan();
  void refreshRequests();
  void refreshStars();
  resumeDm();
}

/**
 * Create or update this device's account. A number starts an SMS code where a
 * provider is configured; where none is, the number is saved but explicitly
 * NOT treated as verified — see the note we surface to the user.
 */
export async function signUp(name: string, phone?: string): Promise<SignUpResult> {
  // The ad that brought them travels with the signup — this is the moment
  // attribution becomes a conversion instead of a pageview.
  let utm: unknown = null;
  try { utm = JSON.parse(localStorage.getItem('num-utm') ?? 'null'); } catch { /* fine */ }
  const out = await api<Partial<MeResponse> & Partial<RecoveryResponse>>('/me', {
    method: 'POST',
    body: JSON.stringify({ id: deviceId(), name, phone, dest: store.get().place, utm }),
  });
  // OUTCOME 2 — this number is already on Num, so this is a sign-IN.
  //
  // The server has texted a code to the number ON FILE and told us nothing
  // else: no member, no id. That is not a failure and it must not read like
  // one. The person is not locked out, they are one code away from everything
  // they already had, and the words below are the ones they need to see
  // BEFORE the code box appears.
  //
  // Checked before `out.me` is touched, because on this path there is no
  // `out.me` to touch.
  if (out?.recovery === 'code_sent') {
    recoveringPhone = out.phone ?? phone ?? null;
    narrate(
      out.verification?.channel === 'review'
        ? 'That number already has an account here. Enter the sign-in code and I will bring it back.'
        : 'That number is already on Num — which means you have an account, not that you are locked out.\n\nI have just texted it a six-digit code. Type it in and everything comes back: your friends, your plans, your Stars.',
    );
    // Not `sign_up`: nobody signed up, somebody came back. Counting a
    // recovery as a fresh signup would inflate the exact number the ad
    // budget is judged against.
    track('signup_recovery', { method: 'phone' });
    return { outcome: 'code_sent', phone: recoveringPhone, verification: out.verification ?? null };
  }

  // OUTCOME 1 — a new number, and an account to go with it.
  //
  // Belt and braces. The fetch layer above now refuses a non-JSON response,
  // but `out.me` is dereferenced four times below and a signup that half-works
  // is the worst screen in the product to be stuck on — you cannot get past
  // it, and the error names a minified variable. If the server ever returns a
  // shape we do not expect, say so in words.
  if (!out?.me?.id) {
    throw new Error("Couldn't finish signing you up — Num didn't send an account back. Try again in a moment.");
  }
  // Pinned to a local, because TypeScript widens a narrowed property back to
  // `Member | undefined` inside the callbacks below — and `out.me!` would be a
  // promise to the compiler that only this line can keep.
  const account: Member = out.me;
  // The "add my name & number" prompt has done its job — leave it up and it
  // reads as if nothing happened.
  store.set((s) => ({
    me: account,
    chips: s.chips.filter((c) => c.id !== 'signup'),
    msgs: [
      ...s.msgs,
      {
        who: 'c' as const,
        // Acknowledge the person, not the transaction — then ask the one
        // question that unlocks everything else.
        text: `Good to meet you, ${account.name ?? 'you'}.${
          account.phone ? '\n\nYour number’s tucked away — friends can find you now, and I’ll tell you if anything moves.' : ''
        }\n\nSo, where in the world are you, and where are you headed next?`,
      },
    ],
  }));

  // The account exists. This is the widest real conversion we have while SMS
  // verification is blocked — it has volume (Google needs roughly 50 events
  // before its optimiser stops guessing) but it only proves someone filled in
  // a form. `first_ask` below is the one that proves they found the product
  // useful. Send both and judge on the second.
  track('sign_up', {
    method: account.phone ? 'phone' : 'name_only',
    // Recovery returns an existing account rather than creating one. Counting
    // it as a fresh signup would inflate exactly the number we spend against.
    recovered: !!(out as { recovered?: boolean }).recovered,
  });

  // Attribute the referral that brought them in, then accept the invite that
  // carried it — that second call is what makes the friendship mutual.
  const { refCode, inviteToken } = store.get();
  if (refCode) {
    void fetch(`${CLAIM}/ref/signup`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code: refCode, token: inviteToken, signup_id: account.id }),
    }).catch(() => {});
  }
  if (inviteToken) await acceptInvite(inviteToken);
  const { connectTo } = store.get();
  if (connectTo) await connectByCode(connectTo);
  // A `?dm=` link that landed before this device had an account — now it does,
  // so open the conversation they were sent here for.
  resumeDm();
  return {
    outcome: 'account',
    me: account,
    ref: out.ref ?? account.ref ?? '',
    link: out.link ?? '',
    verification: out.verification ?? null,
  };
}

/**
 * "Send it again."
 *
 * The server has had a `/resend` route the whole time and nothing in the app
 * has ever called it. A person whose text did not arrive had exactly one
 * option: close the sheet, come back, and hope — which lands on the recovery
 * branch, and until 30 Aug 2026 that branch said "welcome back" and sent
 * nothing at all.
 *
 * BY NUMBER WHEN THERE IS NO ID, and that is the common case rather than the
 * edge one: recovery deliberately withholds the member id until a code proves
 * possession, so the person most likely to press this button is precisely the
 * one we cannot name. `verifyCode` above solves the same problem the same way.
 *
 * Errors are NOT swallowed. A resend button that reports success it did not
 * have is worse than no button, because it converts "no text arrived" into
 * "no text arrived and the app is lying to me". The throttle sentences are
 * written for people on the server; they come through untouched.
 */
export type ResendOutcome = {
  sent: boolean;
  already?: boolean;
  /** What became of the PREVIOUS code, when Twilio has resolved it. */
  previous?: { delivered: boolean; error_code: string | null; hint: string | null } | null;
};

export async function resendCode(phone?: string): Promise<ResendOutcome> {
  const me = store.get().me;
  const recovering = me ? null : (phone ?? recoveringPhone);
  if (!me && !recovering) throw new Error('There is no number to send a code to.');
  const out = await api<{ sent?: boolean; already?: boolean; note?: string; previous?: ResendOutcome['previous'] }>(
    '/resend',
    {
      method: 'POST',
      // Never both: the server takes the id path whenever an id is present,
      // so sending a stale one would 404 the person it is meant to rescue.
      body: JSON.stringify(me ? { id: me.id } : { phone: recovering }),
    },
  );
  return { sent: !!out.sent, already: out.already, previous: out.previous ?? null };
}

/**
 * Type the code in. Two callers, two proofs, one endpoint.
 *
 *   have an id  → { id, code }     the ordinary case: proving the number
 *                                  attached to an account we already hold.
 *   no id       → { phone, code }  recovery. The number and the code ARE the
 *                                  proof of possession, and this response is
 *                                  the only place the server will release the
 *                                  member id (`worker/social.mjs` `verifyMe`).
 *
 * The two must never be sent together. The server picks the phone path only
 * when there is no id in the body —
 * `byPhone = !clip(b.id, 40) && !!normalisePhone(b.phone)` — so including a
 * stale id silently puts us back on the id path and 404s.
 */
export async function verifyCode(code: string, phone?: string): Promise<boolean> {
  const me = store.get().me;
  const recovering = me ? null : (phone ?? recoveringPhone);
  if (!me && !recovering) return false;
  const out = await api<{
    ok?: boolean;
    already?: boolean;
    recovered?: boolean;
    review_access?: boolean;
    phone_verified?: boolean;
    me?: Member;
    ref?: string;
  }>('/verify', {
    method: 'POST',
    // `anon` rides along so the server can fold everything Num noticed about
    // this device into the account it just became. Without it, verifying a
    // phone would make Num forget you — see mergeAnon in soulprofile.mjs.
    body: JSON.stringify(me ? { id: me.id, code, anon: anonId() } : { phone: recovering, code, anon: anonId() }),
  });
  if (!out.ok) return false;
  if (out.me?.id) {
    // RECOVERY, second half. This is where the identity is finally released,
    // so this is the only moment the client can learn who it is. Storing it
    // anywhere else — or not at all — means a code screen that succeeds into
    // an app with no account, which looks exactly like a failure.
    recoveringPhone = null;
    adoptMember(out.me);
    track('sign_up', { method: 'phone', recovered: true });
  } else {
    store.set((s) => ({ me: s.me ? { ...s.me, phone_verified: true } : s.me }));
  }
  // THE conversion, once SMS is on: a verified phone is the strongest signal
  // an ad channel can be judged by. Until A2P clears it cannot fire at all,
  // which is why `sign_up` and `first_ask` exist below — a campaign
  // optimising toward an event that never happens is optimising toward
  // nothing.
  //
  // Read from the response rather than assumed: `{ ok: true, already: true }`
  // means the number was ALREADY verified (no new conversion), and the App
  // Review grant deliberately does not set `phone_verified` at all (no claim
  // about a number we never texted).
  if (out.phone_verified) track('verified_signup', { method: 'sms' });
  return true;
}

/** Consent, second half: accepting is what turns a link active both ways. */
/**
 * Act on a scanned "connect with me" code.
 *
 * Quiet when it is a repeat: scanning the same code twice is a normal thing
 * to do by accident, and announcing a connection that already existed makes
 * the app look like it forgot.
 */
export async function connectByCode(memberId: string): Promise<void> {
  const me = store.get().me;
  if (!me || memberId === me.id) {
    store.set({ connectTo: null });
    return;
  }
  try {
    const out = await api<{ friend?: { id: string; name: string }; already?: boolean }>('/connect', {
      method: 'POST',
      body: JSON.stringify({ me: me.id, to: memberId }),
    });
    store.set({ connectTo: null });
    await refreshFriends();
    if (out.friend && !out.already) {
      narrate(`You and ${out.friend.name} are connected. From here our two Nums can pass reservations, addresses and photos straight across — neither of you retypes a thing.`);
    }
  } catch (err) {
    console.warn('[social] connect failed', err);
    store.set({ connectTo: null });
  }
}

/**
 * Redeem a pairing code inside the installed app.
 *
 * This is the other half of the Safari wall: the browser parked the intent,
 * this binds it to the identity that actually matters — the one holding the
 * person's plans, friends and Stars.
 */
/**
 * Remove someone. Optionally block, which is what makes it stick — `invite()`
 * re-friends an existing member instantly, so without a block the person you
 * removed can add you straight back.
 */
export async function unfriend(id: string, block = false): Promise<string | null> {
  const me = store.get().me;
  if (!me) return null;
  try {
    const out = await fetch(apiUrl('/api/account/unfriend'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ me: me.id, id, block }),
    }).then((r) => r.json()) as { ok?: boolean; note?: string };
    await refreshFriends();
    return out.note ?? null;
  } catch {
    return 'Couldn’t do that just now — try again.';
  }
}

/** Why somebody is being reported. Matches REPORT_REASONS in worker/account.mjs. */
export type ReportReason = 'harassment' | 'spam' | 'impersonation' | 'inappropriate' | 'other';

export const REPORT_REASONS: { id: ReportReason; label: string }[] = [
  { id: 'harassment', label: 'Harassment or abuse' },
  { id: 'spam', label: 'Spam or scam' },
  { id: 'impersonation', label: 'Pretending to be someone else' },
  { id: 'inappropriate', label: 'Inappropriate content' },
  { id: 'other', label: 'Something else' },
];

/**
 * Report somebody, and block them at the same time if asked.
 *
 * Apple guideline 1.2 requires an app carrying user-generated content to offer
 * a way to report it, not only a way to block its author. Num carries DMs,
 * plan comments, and profile names and bios that friends can see, so it is a
 * UGC app whether or not it feels like one.
 *
 * Separate from `unfriend(id, block)` on purpose. Removing somebody is a
 * private preference; reporting them says a human should look. Conflating the
 * two would mean either every block raises a case nobody asked for, or a
 * genuine report quietly does nothing.
 */
export async function reportMember(
  id: string,
  reason: ReportReason,
  opts: { note?: string; block?: boolean; context?: string } = {},
): Promise<string | null> {
  const me = store.get().me;
  if (!me) return null;
  try {
    const out = await fetch(apiUrl('/api/account/report'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        me: me.id,
        id,
        reason,
        note: opts.note ?? '',
        block: !!opts.block,
        context: opts.context ?? 'profile',
      }),
    }).then((r) => r.json()) as { ok?: boolean; note?: string; error?: string };
    // A block changes who is on the People shelf, so the list has to catch up
    // or the person they just blocked is still sitting there.
    if (opts.block) await refreshFriends();
    return out.note ?? out.error ?? null;
  } catch {
    return 'Couldn’t send that just now — try again.';
  }
}

/** Leave a plan, or delete it if it's yours. The server decides which. */
export async function removePlan(planId: string): Promise<string | null> {
  const me = store.get().me;
  if (!me) return null;
  try {
    const out = await fetch(apiUrl('/api/account/plan/remove'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ me: me.id, plan_id: planId }),
    }).then((r) => r.json()) as { ok?: boolean; deleted?: boolean; left?: boolean; title?: string; error?: string };
    if (!out.ok) return out.error ?? 'Couldn’t remove that.';
    store.set((st) => ({
      plans: st.plans.filter((p) => p.id !== planId),
      planId: st.planId === planId ? null : st.planId,
    }));
    await refreshPlans();
    return out.deleted ? `${out.title} is gone — everyone's been told.` : `You've left ${out.title}.`;
  } catch {
    return 'Couldn’t remove that just now.';
  }
}

/**
 * Delete the account. Two calls on purpose: the first returns exactly what
 * will be destroyed, the second destroys it. No undo, so the inventory comes
 * first.
 */
export async function deleteAccount(confirm = false): Promise<{
  ok?: boolean; needs_confirm?: boolean; inventory?: Record<string, number>;
  blockers?: string[]; can_delete?: boolean; note?: string;
} | null> {
  const me = store.get().me;
  if (!me) return null;
  try {
    const out = await fetch(apiUrl('/api/account/delete'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ me: me.id, ...(confirm ? { confirm: 'DELETE' } : {}) }),
    }).then((r) => r.json());
    if (out?.ok && out?.deleted) {
      // Leave nothing behind on the device either — a "deleted" account whose
      // data is still in localStorage is not deleted.
      try { localStorage.clear(); } catch { /* private mode */ }
      window.location.replace('/');
    }
    return out;
  } catch {
    return null;
  }
}

/** What the group needs — and whether I'm contributing to it. */
export async function planFit(planId: string): Promise<{
  me_sharing?: boolean; members?: number; sharing?: number; summary?: string;
} | null> {
  const me = store.get().me;
  if (!me) return null;
  try {
    return await api(`/plan/fit?plan_id=${encodeURIComponent(planId)}&me=${encodeURIComponent(me.id)}`);
  } catch {
    return null;
  }
}

/** Flip MY sharing for one plan. The server only lets me flip my own row. */
export async function shareWithPlan(planId: string, share: boolean): Promise<boolean> {
  const me = store.get().me;
  if (!me) return false;
  try {
    const out = await api<{ ok?: boolean; sharing?: boolean }>('/plan/share', {
      method: 'POST',
      body: JSON.stringify({ me: me.id, plan_id: planId, share }),
    });
    return !!out.sharing;
  } catch {
    return share ? false : true; // failed flip = state unchanged
  }
}

export async function redeemPairCode(code: string): Promise<string | null> {
  const me = store.get().me;
  const clean = code.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
  if (!me || clean.length < 6) return 'Enter the six characters from the link.';
  try {
    const r = await fetch(apiUrl('/api/social/pair/redeem'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ me: me.id, code: clean }),
    });
    const d = (await r.json()) as { error?: string };
    if (!r.ok) return d.error ?? 'That didn’t go through.';
    await refreshFriends();
    await refreshPlans();
    store.set({ pairCode: null });
    return null;
  } catch {
    return 'Couldn’t reach Num — try again in a moment.';
  }
}

export async function acceptInvite(token: string): Promise<void> {
  const me = store.get().me;
  if (!me) return;
  try {
    const out = await api<{ friend?: { id: string; name: string }; plan?: { id: string; title: string } }>('/accept', {
      method: 'POST',
      body: JSON.stringify({ me: me.id, token }),
    });
    store.set({ inviteToken: null });
    await refreshFriends();
    if (out.plan) {
      await openPlan(out.plan.id);
      narrate(`You’re in — ${out.plan.title}. ${out.friend?.name ?? 'Your friend'}’s Num and mine are talking now: whatever either side books, the whole group sees it here.`);
    } else if (out.friend) {
      narrate(`Connected with ${out.friend.name}. From here our two Nums can hand each other reservations, addresses and photos without either of you retyping a thing.`);
    }
  } catch (err) {
    console.warn('[social] accept failed', err);
  }
}

// ── friends & contacts ─────────────────────────────────────────────────────

export async function refreshFriends(): Promise<void> {
  const me = store.get().me;
  if (!me) return;
  try {
    const out = await api<{ friends: Friend[] }>(`/friends?me=${encodeURIComponent(me.id)}`);
    store.set({ friends: out.friends });
  } catch (err) {
    console.warn('[social] friends failed', err);
  }
}

// ── the invite door ────────────────────────────────────────────────────────
//
// Agent-to-agent invites arrive without the member having typed anything, so
// the member decides who may send them: people they're connected to (the
// default), anyone on Num, or nobody. See worker/permissions.mjs.

export type InvitePolicy = 'friends' | 'public' | 'off';

export interface InvitePrefs {
  invite_policy: InvitePolicy;
  accepting: boolean;
  options?: Array<{ value: InvitePolicy; label: string; detail: string }>;
  note?: string;
}

export async function getInvitePolicy(): Promise<InvitePrefs | null> {
  const me = store.get().me;
  if (!me) return null;
  try {
    return await api<InvitePrefs>(`/prefs?me=${encodeURIComponent(me.id)}`);
  } catch (err) {
    console.warn('[social] prefs failed', err);
    return null;
  }
}

/**
 * Set it either way round: a three-way picker passes a policy, a plain switch
 * passes `accepting` and the last open setting so turning it back on restores
 * what they had rather than opening them to strangers.
 */
export async function setInvitePolicy(
  next: InvitePolicy | { accepting: boolean; previous?: InvitePolicy },
): Promise<InvitePrefs | null> {
  const me = store.get().me;
  if (!me) return null;
  const payload = typeof next === 'string' ? { invite_policy: next } : next;
  return await api<InvitePrefs>('/prefs', { method: 'POST', body: JSON.stringify({ me: me.id, ...payload }) });
}

interface ContactsApi {
  select(props: string[], opts?: { multiple?: boolean }): Promise<Array<{ name?: string[]; tel?: string[] }>>;
}
const contactsApi = (): ContactsApi | null =>
  (navigator as Navigator & { contacts?: ContactsApi }).contacts &&
  'ContactsManager' in window
    ? (navigator as Navigator & { contacts?: ContactsApi }).contacts!
    : null;

export const contactsSupported = (): boolean => !!contactsApi();

/**
 * The picker returns only what the user hand-picks — we never read the address
 * book. Chrome/Android has it; iOS Safari has no API at all, which is why the
 * invite sheet always keeps a manual field.
 */
export async function pickContacts(): Promise<Array<{ name: string; phone?: string }>> {
  const api2 = contactsApi();
  if (!api2) return [];
  try {
    const picked = await api2.select(['name', 'tel'], { multiple: true });
    const mapped = picked
      .map((c) => ({ name: c.name?.[0] ?? '', phone: c.tel?.[0] }))
      .filter((c) => c.name);
    if (mapped.length) {
      store.set((s) => ({
        contacts: [...mapped, ...s.contacts.filter((c) => !mapped.some((m) => m.name === c.name))].slice(0, 200),
      }));
    }
    return mapped;
  } catch {
    return []; // user dismissed the picker
  }
}

const norm = (v: string) => v.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();

/**
 * "send invite to sam" → who is sam? We match saved contacts and existing
 * friends and hand back candidates; the user confirms before anything is sent,
 * because an invite goes to a real person's phone.
 */
export function matchPeople(name: string): Array<{ name: string; phone?: string; id?: string | null }> {
  const q = norm(name);
  if (!q) return [];
  const s = store.get();
  const pool: Array<{ name: string; phone?: string; id?: string | null }> = [
    ...s.contacts,
    // Carry the friend's MEMBER ID. Dropping it here is what made a plan
    // invite to a QR-connected friend unroutable — the server had a name and
    // nothing else to match on.
    ...s.friends
      .filter((f) => f.name)
      .map((f) => ({ name: f.name, phone: undefined as string | undefined, id: f.id })),
  ];
  const seen = new Set<string>();
  return pool
    .filter((p) => {
      const n = norm(p.name);
      return n === q || n.startsWith(q) || n.split(/\s+/).some((w) => w.startsWith(q));
    })
    .filter((p) => (seen.has(norm(p.name)) ? false : (seen.add(norm(p.name)), true)))
    .slice(0, 6);
}

/** Open the invite sheet for a named person, pre-resolved where we can. */
export function startInvite(draft: InviteDraft): void {
  const candidates = draft.name ? matchPeople(draft.name) : [];
  store.set({
    inviteOpen: {
      ...draft,
      candidates,
      phone: draft.phone ?? (candidates.length === 1 ? candidates[0].phone : undefined),
      planId: draft.planId ?? store.get().planId,
    },
  });
}

/** Mint the personalised link. Sending stays on the user's own phone. */
export async function mintInvite(name: string, phone?: string, planId?: string | null, toId?: string | null): Promise<void> {
  const me = store.get().me;
  if (!me) {
    store.set({ inviteOpen: { name, phone, planId } });
    narrate('I need your name and number first — an invite has to come from someone. Tap “Set up my Num account” and I’ll send it straight after.');
    return;
  }
  const minted = await api<InviteDraft['minted']>('/invite', {
    method: 'POST',
    body: JSON.stringify({
      from: me.id,
      to_name: name,
      to_phone: phone,
      // If we already know this person's member id — because they're a friend
      // — send it. Without it the server could only match on phone, and a
      // QR-connected friend has no phone stored, so the invite row was born
      // with nothing to match on and became invisible to everyone.
      to_id: toId ?? matchPeople(name).find((c) => c.id)?.id ?? null,
      plan_id: planId ?? store.get().planId,
    }),
  });
  if (name) {
    store.set((s) => ({
      contacts: s.contacts.some((c) => norm(c.name) === norm(name)) ? s.contacts : [...s.contacts, { name, phone }],
    }));
  }
  store.set((s) => ({ inviteOpen: { ...(s.inviteOpen ?? {}), name, phone, planId, minted } }));
  void refreshFriends();
}

/** Hand off to the OS: the invite is sent from the member's own number. */
export async function shareInvite(): Promise<'shared' | 'copied' | 'none'> {
  const minted = store.get().inviteOpen?.minted;
  if (!minted) return 'none';
  const nav = navigator as Navigator & { share?: (d: ShareData) => Promise<void> };
  if (nav.share) {
    try {
      await nav.share({ title: 'Join me on NUM', text: minted.message, url: minted.link });
      return 'shared';
    } catch {
      /* user cancelled — fall through to copy */
    }
  }
  try {
    await navigator.clipboard.writeText(minted.message);
    return 'copied';
  } catch {
    return 'none';
  }
}

// ── plans ──────────────────────────────────────────────────────────────────

function narrate(text: string): void {
  store.set((s) => ({ msgs: [...s.msgs, { who: 'c' as const, text }] }));
}

/**
 * Add, remove, or answer for someone on a reservation.
 *
 * Every call returns the whole attendee list and the recomputed party size,
 * because the server is the only thing entitled to decide either — a client
 * that counts heads locally will eventually disagree with the table the venue
 * is holding.
 */
export async function setAttendee(
  itemId: string,
  name: string,
  opts?: { memberId?: string | null; rsvp?: 'going' | 'maybe' | 'out'; remove?: boolean },
): Promise<{ ok: boolean; message: string }> {
  const me = store.get().me;
  if (!me) return { ok: false, message: 'Add your name and number first.' };
  try {
    const res = await fetch(apiUrl('/api/social/plan/item/attendees'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        me: me.id,
        item_id: itemId,
        name,
        ...(opts?.memberId ? { member_id: opts.memberId } : {}),
        ...(opts?.rsvp ? { rsvp: opts.rsvp } : {}),
        ...(opts?.remove ? { remove: true } : {}),
      }),
    });
    // Same swallow as the one that hid the TestFlight signup crash, found by
    // the test that pins it. Harmless-looking here because nothing is
    // dereferenced deeply — but "the server sent HTML" and "the server sent
    // {}" are different facts, and collapsing them means an RSVP silently
    // does nothing while reporting success.
    let body: { error?: string; attendees?: PlanItem['attendees']; party_size?: number };
    try {
      body = (await res.json()) as typeof body;
    } catch {
      return { ok: false, message: 'That didn’t go through — Num didn’t answer properly. Try again?' };
    }
    if (!res.ok) return { ok: false, message: body.error ?? 'That didn’t go through.' };
    // Patch the item in place rather than re-syncing the whole plan: the
    // answer we just got back IS the truth, and a full sync would make a tap
    // feel slow for no extra correctness.
    store.set((st) => ({
      planItems: st.planItems.map((i) =>
        i.id === itemId ? { ...i, attendees: body.attendees, party_size: body.party_size } : i,
      ),
    }));
    return { ok: true, message: '' };
  } catch {
    return { ok: false, message: 'That didn’t go through.' };
  }
}

export async function refreshPlans(): Promise<void> {
  const me = store.get().me;
  if (!me) return;
  try {
    const out = await api<{ plans: PartyPlan[] }>(`/plans?me=${encodeURIComponent(me.id)}`);
    store.set((s) => ({ plans: out.plans, planId: s.planId ?? out.plans[0]?.id ?? null }));
  } catch (err) {
    console.warn('[social] plans failed', err);
  }
}

/**
 * A plan needs a title and nothing else — no dates, no reservations. That is
 * the point: the group starts planning, and items firm up into bookings later.
 */
export async function createPlan(title: string, dest?: string | null, startsOn?: string | null): Promise<PartyPlan | null> {
  const me = store.get().me;
  if (!me) {
    narrate('Give me your name and number first and I’ll open the plan under your account, so you can pull friends into it.');
    return null;
  }
  // A failure here used to be invisible: api() throws, nothing caught it, and
  // the caller's try/finally only reset the spinner — so START THE PLAN read as
  // a dead button rather than as something that went wrong. Say what happened.
  try {
    const out = await api<{ plan: PartyPlan }>('/plan', {
      method: 'POST',
      body: JSON.stringify({ me: me.id, title, dest: dest ?? store.get().place, starts_on: startsOn }),
    });
    store.set((s) => ({ plans: [out.plan, ...s.plans], planId: out.plan.id, planItems: [], planCursor: 0 }));
    return out.plan;
  } catch (err) {
    console.warn('[social] createPlan failed', err);
    narrate(`I couldn’t start that plan just now — ${(err as Error).message}. Try again in a moment.`);
    return null;
  }
}

export async function openPlan(id: string): Promise<void> {
  store.set({ planId: id, planItems: [], planCursor: 0, planFeed: [] });
  await syncPlan();
}

/**
 * Set WHEN the plan happens. The server broadcasts a 'scheduled' event (feed +
 * push to every other member) and each client mirrors the plan onto its own
 * calendar on the next sync — the Frienzy moment: pick a date, and it's on
 * everyone's calendar.
 */
export async function schedulePlan(date: string, time?: string): Promise<void> {
  const { me, planId } = store.get();
  if (!me || !planId || !date) return;
  try {
    const out = await api<{ plan: PartyPlan }>('/plan', {
      method: 'POST',
      body: JSON.stringify({ me: me.id, id: planId, starts_on: date, starts_time: time ?? null }),
    });
    store.set((s) => ({ plans: s.plans.map((p) => (p.id === out.plan.id ? out.plan : p)) }));
    await syncPlan();
  } catch (err) {
    console.warn('[social] schedule failed', err);
  }
}

/** "Are you in on this plan?" — the whole-plan answer, changeable until booked. */
export async function votePlan(vote: 'in' | 'out'): Promise<void> {
  const { me, planId } = store.get();
  if (!me || !planId) return;
  try {
    await api('/plan/vote', { method: 'POST', body: JSON.stringify({ me: me.id, plan_id: planId, vote }) });
    await syncPlan();
  } catch (err) {
    console.warn('[social] vote failed', err);
  }
}

/**
 * Which of these phones already belong to Num members. Boolean per phone,
 * nothing else — the server refuses to be a reverse phone book (see
 * lookupPhones in worker/social.mjs for the guardrails).
 */
export async function whoIsOnNum(phones: string[]): Promise<Map<string, boolean>> {
  const me = store.get().me;
  const map = new Map<string, boolean>();
  if (!me || !phones.length) return map;
  try {
    const out = await api<{ results: Array<{ phone: string; on_num: boolean }> }>('/lookup', {
      method: 'POST',
      body: JSON.stringify({ me: me.id, phones: phones.slice(0, 20) }),
    });
    for (const r of out.results) map.set(r.phone, r.on_num);
  } catch (err) {
    console.warn('[social] lookup failed', err);
  }
  return map;
}

export async function commentOnPlan(text: string): Promise<boolean> {
  const { me, planId } = store.get();
  const t = text.trim();
  if (!me || !planId || !t) return false;
  try {
    await api('/plan/comment', {
      method: 'POST',
      body: JSON.stringify({ me: me.id, plan_id: planId, text: t }),
    });
    await syncPlan();
    return true;
  } catch (err) {
    console.warn('[social] comment failed', err);
    return false;
  }
}

export async function addPlanItem(item: Partial<PlanItem>): Promise<PlanItem | null> {
  const me = store.get().me;
  const planId = item.plan_id ?? store.get().planId;
  if (!me || !planId) return null;
  // Same reason as createPlan: an uncaught throw here is a button that does
  // nothing, which is indistinguishable from a broken app.
  try {
    const out = await api<{ item: PlanItem }>('/plan/item', {
      method: 'POST',
      body: JSON.stringify({ me: me.id, plan_id: planId, ...item }),
    });
    store.set((s) => ({ planItems: [...s.planItems.filter((i) => i.id !== out.item.id), out.item] }));
    return out.item;
  } catch (err) {
    console.warn('[social] addPlanItem failed', err);
    narrate(`That didn’t get added — ${(err as Error).message}.`);
    return null;
  }
}

/** Promote an idea to a real reservation once it is actually booked. */
export async function confirmPlanItem(id: string, patch: Partial<PlanItem> = {}): Promise<void> {
  const me = store.get().me;
  const planId = store.get().planId;
  if (!me || !planId) return;
  const out = await api<{ item: PlanItem }>('/plan/item', {
    method: 'POST',
    body: JSON.stringify({ me: me.id, plan_id: planId, id, status: 'confirmed', kind: 'booking', ...patch }),
  });
  store.set((s) => ({ planItems: s.planItems.map((i) => (i.id === out.item.id ? out.item : i)) }));
}

/**
 * The agent-to-agent channel. Everything the other members' Nums did since we
 * last looked comes back as one-line summaries, and this Num says them in the
 * thread — which is what "the AIs talk to each other" actually looks like from
 * inside the app.
 */
export async function syncPlan(): Promise<void> {
  const { me, planId, planCursor } = store.get();
  if (!me || !planId) return;
  try {
    const out = await api<{
      plan: PartyPlan;
      members: Array<{ member_id: string; name: string | null; role: string }>;
      items: PlanItem[];
      events: Array<{ id: number; ts: string; by_id: string | null; by_name: string | null; kind: string; summary: string }>;
      cursor: number;
    }>(`/plan?id=${encodeURIComponent(planId)}&me=${encodeURIComponent(me.id)}&since=${planCursor}&self=1`);

    store.set((s) => ({
      // The fresh plan carries starts_on/starts_time — the header and the
      // WHEN pickers read it from the plans list, so keep that list current.
      plans: s.plans.some((p) => p.id === out.plan.id)
        ? s.plans.map((p) => (p.id === out.plan.id ? out.plan : p))
        : [out.plan, ...s.plans],
      planItems: out.items,
      planMembers: out.members,
      planCursor: out.cursor,
      // Append-and-dedupe: openPlan resets the cursor to 0, so a reopen
      // re-delivers history and must not double every line.
      planFeed: (() => {
        const seen = new Set(s.planFeed.map((e) => e.id));
        return [...s.planFeed, ...out.events.filter((e) => !seen.has(e.id))];
      })(),
    }));

    // A confirmed group booking belongs on this member's own shelf too —
    // including ones that were already confirmed before this member first
    // opened the plan, which is why this is not gated on "news".
    out.items
      .filter((i) => i.status === 'confirmed' && i.day)
      .forEach((i) => mirrorToBookings(i));

    // The plan ITSELF, once dated, is a calendar entry for every member — the
    // whole point of the group choosing a date. Same mirror pattern as items.
    if (out.plan?.starts_on) mirrorPlanDate(out.plan);

    // Narration is for what happened while you weren't looking — OTHER
    // people's doing. self=1 means the response now includes your own events
    // (the thread needs them), so narration must drop everything by you, and
    // the initial history load (cursor 0) is the past, not news.
    const first = planCursor === 0;
    const news = out.events.filter((e) => e.by_id !== me.id);
    if (news.length && !first) {
      const line = (e: (typeof news)[number]) =>
        e.kind === 'comment' ? `${e.by_name || 'Someone'} said: “${e.summary}”` : e.summary;
      const lines = news.map((e) => '· ' + line(e)).join('\n');
      narrate(
        news.length === 1
          ? `${line(news[0])} — it's on the group plan; open PLANS to reply.`
          : `Group plan moved while you were away:\n${lines}`,
      );
    }
  } catch (err) {
    console.warn('[social] sync failed', err);
  }
}

/** A confirmed group item becomes a booking on every member's PLAN shelf. */
function mirrorToBookings(item: PlanItem): void {
  const id = 'grp_' + item.id.slice(-8);
  const [y, m, d] = (item.day ?? '').split('-').map(Number);
  if (!m || !d) return;
  const booking: Booking = {
    id,
    mo: m,
    day: d,
    time: item.time ?? '19:00',
    dur: 120,
    place: item.address || item.place || '',
    title: item.title,
    grp: 'BKK',
    status: 'confirmed',
    note: [item.note, item.by_name ? `Added by ${item.by_name} on the group plan.` : null].filter(Boolean).join(' '),
    cost: item.cost ?? '',
    ...(item.photo ? { photo: item.photo } : {}),
  };
  void y;
  store.set((s) => ({
    bookings: s.bookings.some((b) => b.id === id)
      ? s.bookings.map((b) => (b.id === id ? { ...b, ...booking } : b))
      : [...s.bookings, booking],
  }));
}

/** The dated plan as a calendar entry on this member's shelf. */
export function mirrorPlanDate(plan: PartyPlan): void {
  const [y, m, d] = (plan.starts_on ?? '').split('-').map(Number);
  if (!m || !d) return;
  void y;
  const id = 'pld_' + plan.id.slice(-8);
  const booking: Booking = {
    id,
    mo: m,
    day: d,
    time: plan.starts_time ?? '19:00',
    dur: 120,
    place: plan.dest ?? '',
    title: plan.title,
    // Booking.grp is a fixed union of known city codes; a plan can be for
    // anywhere, so coin the 3-letter code the same way the model does and cast.
    grp: (((plan.dest ?? 'NUM').replace(/[^A-Za-z]/g, '').slice(0, 3).toUpperCase() || 'NUM')) as Booking['grp'],
    status: 'confirmed',
    note: 'Group plan — everyone on the plan sees this.',
    cost: '',
  };
  store.set((s) => ({
    bookings: s.bookings.some((b) => b.id === id)
      ? s.bookings.map((b) => (b.id === id ? { ...b, ...booking } : b))
      : [...s.bookings, booking],
  }));
}

/**
 * The other direction: a booking this member's Num just made is pushed to the
 * shared plan, so everyone else's Num can announce it on their side.
 */
export async function pushBookingToPlan(b: Booking): Promise<void> {
  const { me, planId } = store.get();
  if (!me || !planId || b.id.startsWith('grp_')) return;
  const day = `2026-${String(b.mo).padStart(2, '0')}-${String(b.day).padStart(2, '0')}`;
  await addPlanItem({
    kind: 'booking',
    title: b.title,
    place: b.place,
    address: b.place,
    day,
    time: b.time,
    status: b.status === 'confirmed' ? 'confirmed' : b.status === 'hold' ? 'held' : 'proposed',
    cost: b.cost,
    note: b.note,
    photo: b.photo,
  }).catch(() => null);
}

/**
 * A shared reservation that CHANGED. The plan item is matched by title, since
 * that is what both sides carry, and the event feed does the telling — a
 * friend who was never told the dinner moved is the failure this prevents.
 */
export async function pushBookingUpdateToPlan(bookingId: string): Promise<void> {
  const { me, planId, bookings, planItems } = store.get();
  if (!me || !planId) return;
  const b = bookings.find((x) => x.id === bookingId);
  if (!b) return;
  const norm = (v: string) => v.toLowerCase().replace(/[^a-z0-9]/g, '');
  const item = planItems.find((i) => norm(i.title) === norm(b.title));
  if (!item) return void pushBookingToPlan(b);
  const day = `2026-${String(b.mo).padStart(2, '0')}-${String(b.day).padStart(2, '0')}`;
  await api('/plan/item', {
    method: 'POST',
    body: JSON.stringify({
      me: me.id,
      plan_id: planId,
      id: item.id,
      day,
      time: b.time,
      place: b.place,
      address: b.place,
      note: b.note,
      cost: b.cost,
      status: b.status === 'confirmed' ? 'confirmed' : b.status === 'cancelled' ? 'cancelled' : b.status === 'hold' ? 'held' : 'proposed',
    }),
  }).catch(() => null);
  await syncPlan();
}

/** Poll while the app is in the foreground; stop when it is backgrounded. */
export function startPlanSync(): () => void {
  let timer: ReturnType<typeof setInterval> | undefined;
  const start = () => {
    stop();
    // No `planId` guard: the inbox matters even before you belong to a plan.
    // Requests ride the same clock as the plan sync — a friend's invite should
    // be waiting for you, not something you go looking for.
    timer = setInterval(() => {
      void syncPlan();
      void refreshRequests();
      void refreshStars();
      // Friends and plans were the ONLY social reads missing from this clock,
      // which is exactly why they were the ones that looked half-landed: the
      // server wrote the row and buzzed the phone, and the list on screen kept
      // showing the world as it was at app launch. Someone adds you to a plan
      // and it appears — without a restart.
      void refreshFriends();
      void refreshPlans();
    }, 45_000);
  };
  const stop = () => {
    if (timer) clearInterval(timer);
    timer = undefined;
  };
  const onVis = () => {
    if (document.visibilityState === 'visible') {
      void syncPlan();
      void refreshRequests();
      start();
    } else stop();
  };
  document.addEventListener('visibilitychange', onVis);
  start();
  return () => {
    stop();
    document.removeEventListener('visibilitychange', onVis);
  };
}
