# Status for Duke — 2026-08-01 (from Dre's session, digest of #num + today's work)

Duke reads the artifacts, so this is your copy of record. Sources: Viv's
production-verified status (Slack #num, 15:28 PT) + Dre-side session logs.

## 1. The 5arz connection is LIVE in prod — finish it, don't build it (Viv, verified)
- LEDGER->5arz-ledger bound; verify/5arz past guard; /api/air connected:true
- 5arz: 141 members / 102 verified / 91 google_sub / 15 scored sessions / 0 UHA
- NUM: 74 members / 1 linked / 0 phone-verified / 0 AiR calls
- **Gap 1 (SECURITY, yours): GOOGLE_CLIENT_ID unset** — audience check skipped;
  any Google token from any app accepted. `npx wrangler secret put
  GOOGLE_CLIENT_ID --config wrangler.app.jsonc`
- **Gap 2: CLOSED by Dre's session (0.8.87)** — Verify5arz.tsx in the profile:
  GIS sign-in -> POST verify/5arz -> all four outcomes rendered. Dark until
  your Gap-1 secret exists; /api/version serves google_client_id so client
  and audience check can never disagree. Verified dark-safe in prod.
- **Gap 3 (yours): AIR_SHARED_KEY unset** — /api/trust 401s everyone.
- NOT blockers for this path: JWKS oracle mismatch (gates UHA only, 0 rows),
  num-core migration. Track A-prime still gates UHA/nodes.
- Claim limit: sell "verified identity + scored work sessions" (102/15), not
  "attested unique humans" (0).

## 2. Email (Viv's 29h audit): 800 sends, 709 ok, 91 bounce, 0 complaints
- Merchant campaign bounce 17.25
## UPDATE 2026-08-01 late — Gap 1 CLOSED by Dre
GOOGLE_CLIENT_ID set on num-app (the existing "NUM Web" OAuth client in the
5arz GCP project, origins verified). Confirmed live: /api/version reports
verify_5arz:true and serves the client id; audience check now enforced.
Remaining from your list: AIR_SHARED_KEY only.

## Addendum 2 — pay rail + connections (0.8.91/0.8.92, later 08-01)

- **Connect Your World is real now** (0.8.91): contact/photo pickers, calendar auto-mirror, read-only wallet link, per-member email forward address (`num+<id>@itsnum.com`, worker `email()` handler shipped — needs Email Routing catch-all on itsnum.com flipped to the num-app worker), and inbound SMS at `/api/sms/inbound` with **Twilio signature verification** (403 otherwise — probed live).
- **Pay rail** (0.8.92): Stripe Checkout end-to-end behind `STRIPE_SECRET_KEY`; `/api/pay/webhook` verifies Stripe signatures per your §8 rule (unsigned → 400, probed live). The wallet's top-up buttons no longer fake-credit Stars.
- **§8 "Never sell Stars" is enforced in code**: `/api/pay/request` refuses any `stars:*` purchase with a 403 unless `STARS_SALE_OK=1` is set. That env var is yours to set or never set — bills/tabs/bookings/bounties are unaffected and can charge the moment a Stripe key exists. Money flows provider→recipient via Stripe; we hold nothing.

## Addendum 3 — NUM Stars are closed-loop (0.8.99)

Clarifying a conflation in Addendum 2. There are **two Star economies** and they
must not be reasoned about together:

| | 5arz `stars_ledger` | NUM `num_star_balances` |
|---|---|---|
| Worker | `num-payouts` / 5arz | `num-app` |
| Cash-out | yes — USDC payout methods on file | **none, by construction** |
| Your §8 rule | applies | see below |

NUM Stars have **no path to money**: no cash-out endpoint, no refund-to-card, no
transfer to an outside wallet. They move member → escrow → member inside
`worker/errands.mjs` and stop. This is now stated and exported as `CLOSED_LOOP`
in `worker/pay.mjs`, served on `/api/pay/status`, and reflected in app copy —
the wallet's old "1★ ≈ $0.30" line read as an exchange rate and is gone.

Because we never owe a Star holder money back — only service inside Num — a
paid top-up is prepaid credit for our own service rather than stored value we
hold and remit. That is a materially narrower question than the one §8 was
written against, but it is **still your call with counsel**, so the switch is
untouched: `/api/pay/request` refuses `stars:*` unless `STARS_SALE_OK=1`.

**If you do open it, the invariant to defend is:** never add a cash-out to
`num_star_balances`, and never merge it with `stars_ledger`. That single line is
what the posture rests on.

## Addendum 4 — two wallets, one direction (0.8.101)

Dre's call, and it is the right one: **Num and 5arz are separate wallets.**

```
NUM wallet  ──── cash out ────▶  5arz wallet
NUM wallet  ◀──── NOTHING ────   5arz wallet
```

5arz Stars never enter Num — not as a transfer, a top-up, or a "link your
balance" convenience. Reasons, in order of how much they'd cost us:

1. If 5arz Stars could enter Num and leave through Num's payout, Num becomes a
   second exit for someone else's balance — a value-transfer service, which is
   the licensing shape we are avoiding.
2. Your Track-A drift (21 of 80 members) lives in `stars_ledger`. Importing its
   numbers imports its bugs into a ledger that is currently clean.
3. One-way means a bug over there can never mint Stars over here.

**Enforced, not just written down.** `worker/cashout.test.mjs` reads the actual
source and fails the build on: a new place that credits `num_star_balances`
(allowlisted by file, with reasons), any `fetch` to a 5arz host, and any query
naming `stars_ledger` / `member_finance` / `payable_stars`. I verified it bites
by adding a real import and watching two tests fail.

That test also surfaced three credit sites in `social.mjs` I had not audited —
member→member transfer, its rollback, and tab settlement. All three move Stars
between Num members; none mints and none reaches outside. Recorded in the
allowlist with that reasoning.

Cash-out itself remains gated on `CASHOUT_OK` pending your Track A.

## Addendum 5 — Num payouts open, partner payouts stay paused (0.8.103)

Dre's decision: **Num-originated cash-outs are LIVE. 5arz-native payouts remain
paused.** Opening one did not open the other, and the record now makes that
distinguishable rather than a matter of trust.

Every request `num-app` files carries `origin = 'num'` — a module constant, not
a request field, so no caller can claim to be a partner-native payout and ride
the Num queue's open switch. `num_cashouts` gained an `origin` column (applied
live) and an `(origin, state)` index so the desk can filter cheaply.

**What the payout desk must do:** process only `origin = 'num'`. Partner-native
payouts stay queued until Track A closes. If the desk currently drains the
whole table, that is the one change needed before the next run.

`/api/cashout/status` now reports `scope: "num-originated cash-outs only"` so
this is legible from outside without reading code.

Guarded by `worker/cashout.test.mjs` (7 tests): origin is a constant, never
taken from a body. Note the test also caught me — an explanatory comment naming
a partner ledger table failed the "no partner ledger in num-app" check, which is
the check doing its job.

**Still true and still yours:** the Num ledger is clean; the drift is on the
partner side, which is where these settle. First payouts are small. Worth a
manual eyeball on the first few settlements.

## Addendum 6 — the cash-out bridge, and the one thing only you can decide (0.8.121)

**What was broken.** Cash-out debited a member's Stars, wrote a row into
`num_cashouts` (num-db), and told them "on its way to 5arz". Your desk reads
`cashout_requests` in the 5arz ledger and never saw it. Money left the balance
and reached nobody; every layer reported success. `CASHOUT_OK` was ON for a few
hours today. No member cash-out was attempted in that window — checked.

**What now happens.** `worker/payoutdesk.mjs` calls your `/request` endpoint
(session-authed with `PAYOUT_DESK_KEY`, same scheme as the console) and the
balance moves ONLY after the desk answers with a reference. Refusal, timeout or
missing config → the member's Stars are untouched and they're told exactly
that. Our idempotency key is stable per attempt, so a retry after a timeout
resolves to your existing request instead of queueing a second payout.
`CASHOUT_OK=1` alone can no longer open cash-out — `deskReady()` must also be
true, so the switch can't promise a road that doesn't arrive. Two tests pin the
ordering; a future refactor that moves the debit back above the desk call fails
the build.

**THE DECISION THAT IS YOURS.** Your desk pays from `member_finance.stars_earned`
in the 5arz ledger. Num-earned Stars are in num-db and are NOT in that ledger,
so today your desk would answer "Only 0 Stars available" for every Num member.
I did not work around this. The two ways I can see:

1. **Desk reads Num for `origin: 'num'`** — we already send that field. Your
   side binds num-db read-only and takes the earned balance from
   `num_star_moves`. Wallets stay separate; one ledger stays authoritative for
   each economy. This is the option I'd argue for.
2. **Num funds a 5arz balance first** — merges the two wallets, which is the
   boundary Dre asked for and which `cashout.test.mjs` now enforces. I'd need
   an explicit instruction to undo that, and I don't recommend it.

Until you pick, cash-out stays closed and honest. Nothing is queued, nothing is
owed, and nobody is told otherwise.
