/**
 * The invite HTML, embedded as a string.
 *
 * Workers have no filesystem, so this cannot `readFileSync` campaign/invite_v2.html
 * the way the CLI sender (scripts/send_invites.mjs) does. Rather than keep a
 * second hand-copied template that drifts from the one marketing edits, this
 * file is REGENERATED from campaign/invite_v2.html by
 * scripts/build_invite_template.mjs — never hand-edit the string below.
 * Edit the .html, then run: node scripts/build_invite_template.mjs
 */
export const INVITE_TEMPLATE = `
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="x-apple-disable-message-reformatting">
<title>{{business_name}} — claim your AI profile on NUM</title>
<style>
  @media only screen and (max-width:620px){
    .w{width:100%!important}
    .px{padding-left:22px!important;padding-right:22px!important}
    .h1{font-size:27px!important;line-height:1.22!important}
    .stack{display:block!important;width:100%!important}
    .bub{max-width:88%!important}
  }
  a{text-decoration:none}
</style>
</head>
<body style="margin:0;padding:0;background:#EEF0FA;-webkit-font-smoothing:antialiased;">

<div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;height:0;width:0">{{preheader}}&#8203;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;</div>

<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#EEF0FA">
<tr><td align="center" style="padding:28px 12px 40px">

<table role="presentation" class="w" width="600" cellpadding="0" cellspacing="0" border="0" style="width:600px;max-width:600px">

  <!-- ── Brand bar ───────────────────────────────────────────── -->
  <tr><td align="center" style="padding:0 0 18px">
    <span style="font-family:Georgia,'Times New Roman',serif;font-style:italic;font-size:26px;font-weight:700;color:#4A4F86;letter-spacing:-.5px">NuM</span>
    <span style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:12px;color:#8A90B4;letter-spacing:.14em;text-transform:uppercase;padding-left:9px">by 5arz</span>
  </td></tr>

  <!-- ── Card ────────────────────────────────────────────────── -->
  <tr><td style="background:#FFFFFF;border-radius:20px;overflow:hidden;box-shadow:0 12px 40px rgba(45,50,110,.10)">

    <!-- gradient top -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr><td style="background:#6366F1;background:linear-gradient(135deg,#6366F1 0%,#8B5CF6 55%,#A855F7 100%);height:6px;line-height:6px;font-size:0">&nbsp;</td></tr>
    </table>

    <!-- headline block -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr><td class="px" style="padding:34px 42px 0">
        <div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:11.5px;font-weight:700;letter-spacing:.13em;text-transform:uppercase;color:#7C7FE8">AI text-message concierge &middot; {{place_line}}</div>
        <h1 class="h1" style="margin:13px 0 0;font-family:'Helvetica Neue',Arial,sans-serif;font-size:31px;line-height:1.2;font-weight:800;color:#181B3C;letter-spacing:-.6px">
          {{business_name}} already has a profile on NUM.<br>Claim it — free.
        </h1>
        <p style="margin:16px 0 0;font-family:'Helvetica Neue',Arial,sans-serif;font-size:15.5px;line-height:1.62;color:#4E5478">
          {{personal_open}}
        </p>
      </td></tr>
    </table>

    <!-- ── The demo: what an AI profile actually does ──────────── -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr><td class="px" style="padding:28px 42px 0">
        <div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:11.5px;font-weight:700;letter-spacing:.13em;text-transform:uppercase;color:#9AA0C4;padding-bottom:12px">This is what a profile does</div>

        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F5F6FD;border-radius:16px">
          <tr><td style="padding:20px 20px 6px">

            <!-- traveller -->
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>
              <td align="right">
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" class="bub" style="max-width:78%">
                  <tr><td style="background:#E2E5F6;border-radius:16px 16px 4px 16px;padding:11px 15px;font-family:'Helvetica Neue',Arial,sans-serif;font-size:14.5px;line-height:1.5;color:#2C3054">{{traveller_ask}}</td></tr>
                </table>
                <div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:11px;color:#9AA0C4;padding:5px 3px 0">a traveller, 8 minutes away</div>
              </td>
            </tr></table>

            <!-- num -->
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="padding-top:14px"><tr>
              <td align="left" style="padding-top:14px">
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" class="bub" style="max-width:82%">
                  <tr><td style="background:#6366F1;background:linear-gradient(135deg,#6366F1,#8B5CF6);border-radius:16px 16px 16px 4px;padding:12px 16px;font-family:'Helvetica Neue',Arial,sans-serif;font-size:14.5px;line-height:1.55;color:#FFFFFF">{{num_reply}}</td></tr>
                </table>
                <div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:11px;color:#9AA0C4;padding:5px 3px 0">NUM &middot; answering in the traveller's own language</div>
              </td>
            </tr></table>

          </td></tr>
          <tr><td style="padding:14px 20px 18px">
            <div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:13.5px;line-height:1.6;color:#5E6489;border-top:1px solid #E4E7F6;padding-top:13px">
              That answer comes from your profile. <b style="color:#2C3054">Claimed profiles get recommended. Unclaimed ones sit as a name on a map.</b>
            </div>
          </td></tr>
        </table>

      </td></tr>
    </table>

    <!-- ── Value ──────────────────────────────────────────────── -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr><td class="px" style="padding:30px 42px 0">

        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
          <tr>
            <td width="30" valign="top" style="font-size:19px;line-height:1.3;padding-bottom:15px">🆓</td>
            <td valign="top" style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:15px;line-height:1.55;color:#4E5478;padding-bottom:15px">
              <b style="color:#181B3C">Free to claim. Free to stay listed.</b><br>No signup fee, no monthly fee, no card.
            </td>
          </tr>
          <tr>
            <td width="30" valign="top" style="font-size:19px;line-height:1.3;padding-bottom:15px">💬</td>
            <td valign="top" style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:15px;line-height:1.55;color:#4E5478;padding-bottom:15px">
              <b style="color:#181B3C">Travellers find you in their own language.</b><br>Chinese, Russian, Thai, English, Korean and more — you never have to translate a thing.
            </td>
          </tr>
          <tr>
            <td width="30" valign="top" style="font-size:19px;line-height:1.3;padding-bottom:15px">📲</td>
            <td valign="top" style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:15px;line-height:1.55;color:#4E5478;padding-bottom:15px">
              <b style="color:#181B3C">Bookings arrive on your phone.</b><br>Accept with one tap. Guests pay you directly, exactly as they do now.
            </td>
          </tr>
          <tr>
            <td width="30" valign="top" style="font-size:19px;line-height:1.3;padding-bottom:15px">💸</td>
            <td valign="top" style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:15px;line-height:1.55;color:#4E5478;padding-bottom:15px">
              <b style="color:#181B3C">{{fee_line}}</b><br>No subscription, no setup fee, no card.
            </td>
          </tr>
          <tr>
            <td width="30" valign="top" style="font-size:19px;line-height:1.3">⭐</td>
            <td valign="top" style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:15px;line-height:1.55;color:#4E5478">
              <b style="color:#181B3C">Real reviews only.</b><br>Every review comes from a verified, completed booking. No anonymous revenge posts.
            </td>
          </tr>
        </table>

      </td></tr>
    </table>

    <!-- ── CTA ────────────────────────────────────────────────── -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr><td class="px" align="center" style="padding:32px 42px 0">
        <table role="presentation" cellpadding="0" cellspacing="0" border="0">
          <tr><td align="center" style="background:#6366F1;background:linear-gradient(135deg,#6366F1,#8B5CF6);border-radius:14px">
            <a href="{{claim_url}}" style="display:inline-block;padding:17px 40px;font-family:'Helvetica Neue',Arial,sans-serif;font-size:16.5px;font-weight:700;color:#FFFFFF;letter-spacing:-.2px">Claim {{business_name_short}} — free &rarr;</a>
          </td></tr>
        </table>
        <div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:13px;line-height:1.6;color:#8A90B4;padding-top:13px">
          Takes about two minutes. No card, no contract.
        </div>
      </td></tr>
    </table>

    <!-- ── LINE alternative ───────────────────────────────────── -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr><td class="px" style="padding:24px 42px 0">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#F5F6FD;border-radius:14px">
          <tr><td style="padding:16px 20px;font-family:'Helvetica Neue',Arial,sans-serif;font-size:13.5px;line-height:1.65;color:#5E6489">
            {{contact_block_html}}
          </td></tr>
        </table>
      </td></tr>
    </table>

    <!-- ── Sign-off ───────────────────────────────────────────── -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr><td class="px" style="padding:26px 42px 36px">
        <div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:14.5px;line-height:1.65;color:#4E5478">
          {{sign_off}}<br><br>
          <b style="color:#181B3C">The NUM team</b><br>
          <span style="color:#8A90B4;font-size:13.5px">5arz &middot; <a href="{{website_url}}" style="color:#5457D8">itsnum.com</a> &middot; <a href="mailto:info@5arz.com" style="color:#5457D8">info@5arz.com</a></span>
        </div>
      </td></tr>
    </table>

  </td></tr>

  <!-- ── Footer / compliance ─────────────────────────────────── -->
  <tr><td class="px" style="padding:22px 42px 0">
    <div style="font-family:'Helvetica Neue',Arial,sans-serif;font-size:11.5px;line-height:1.7;color:#9AA0C4;text-align:center">
      You're receiving this one-time invitation because {{business_name}} is publicly listed as a business in {{place_line}}.<br>
      <a href="{{unsub_url}}" style="color:#7C82AC;text-decoration:underline">Unsubscribe &amp; remove our listing</a>
      &nbsp;&middot;&nbsp;
      <a href="https://itsnum.com/privacy" style="color:#7C82AC;text-decoration:underline">Privacy</a>
      &nbsp;&middot;&nbsp;
      <a href="https://itsnum.com/terms" style="color:#7C82AC;text-decoration:underline">Terms</a>
      <br>{{postal_address}}
      <br>© 2026 5arz. We won't email you again unless you reply.
    </div>
  </td></tr>

</table>

</td></tr>
</table>

<img src="{{pixel_url}}" width="1" height="1" alt="" style="display:block;border:0;width:1px;height:1px;opacity:0">
</body>
</html>
`;
