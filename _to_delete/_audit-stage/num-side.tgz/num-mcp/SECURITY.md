# Security

## Reporting a vulnerability

Email **info@5arz.com** with the details. Please do not open a public issue for
anything exploitable. We aim to acknowledge within two business days.

## Scope

This repository holds documentation and client examples only. The NUM MCP
server itself runs at `https://itsnum.com/mcp` and is operated by 5arz Inc.
Reports about the live endpoint are in scope.

## API keys

Keys issued by `POST /api/agent/signup` are bearer credentials. Treat them as
secrets: do not commit them, and do not embed them in client-side code. If a
key leaks, request a new one and contact us so the old one can be revoked.
