#!/usr/bin/env bash
# Tool discovery on NUM is open — no API key needed to see what is available.
set -euo pipefail

curl -sS -X POST https://itsnum.com/mcp \
  -H 'content-type: application/json' \
  -H 'accept: application/json, text/event-stream' \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | python3 -m json.tool
