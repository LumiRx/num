#!/usr/bin/env bash
# Call a metered tool. Needs a key from get-api-key.sh in NUM_API_KEY.
set -euo pipefail
: "${NUM_API_KEY:?set NUM_API_KEY first}"

curl -sS -X POST https://itsnum.com/mcp \
  -H "authorization: Bearer ${NUM_API_KEY}" \
  -H 'content-type: application/json' \
  -H 'accept: application/json, text/event-stream' \
  -d '{
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
          "name": "num_search_places",
          "arguments": { "city": "Phuket", "category": "Restaurant", "limit": 5 }
        }
      }' | python3 -m json.tool
