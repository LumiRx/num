#!/usr/bin/env bash
# Request a NUM agent API key. Free, no card, instant.
# The key is returned ONCE and is not recoverable — save it immediately.
set -euo pipefail

curl -sS -X POST https://itsnum.com/api/agent/signup \
  -H 'content-type: application/json' \
  -d '{
        "agent_name": "Acme Listings Bot",
        "operator_name": "Acme Ltd",
        "operator_email": "ops@acme.example",
        "homepage": "https://acme.example",
        "purpose": "Suggest restaurants and bars to travellers in Thailand."
      }' | python3 -m json.tool

# agent_name      required — the agent itself
# operator_name   required — the human or company accountable for it
# operator_email  required — must be a working address someone answers
# purpose         required — at least 12 characters, describe it honestly
# homepage        optional
