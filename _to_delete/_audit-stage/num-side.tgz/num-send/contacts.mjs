#!/usr/bin/env node
/**
 * Every business we hold contact details for, one CSV per city.
 *
 * `places` holds 2,529,721 rows and 1,872,688 of them are reachable by phone
 * or email. That is not a spreadsheet — it is four times what a single Excel
 * sheet can hold, and a file nobody can open is not a deliverable. So this
 * exports the cities NUM is actually working, and the workbook step adds a
 * summary sheet covering all 77 destinations so nothing is hidden.
 *
 * Reachable means a phone OR an email. A row with neither cannot be contacted
 * and belongs in the directory, not in a contact sheet.
 *
 * Paged, because a single 78,806-row D1 response is a timeout waiting to
 * happen and a partial answer that looks complete is worse than an error.
 */
import { execFileSync } from 'node:child_process';
import { writeFileSync, mkdirSync } from 'node:fs';

const DB = 'num-db';
const HERE = '/Users/dre/num-worktrees/app-main';
const OUT = '/Users/dre/num-send/contacts/';
const PAGE = 5000;

const CITIES = process.argv.slice(2).length
  ? process.argv.slice(2)
  : ['los-angeles', 'bali', 'phuket', 'edinburgh'];

const COLS = [
  'id', 'name', 'name_local', 'category', 'address', 'area', 'dest', 'country',
  'phone', 'email', 'website', 'rating', 'reviews', 'status',
];

// Same rule as export.mjs: flatten every control character, then quote. A bare
// CR inside an OpenStreetMap name once split one record into two rows and made
// a 7,487-row file report 7,488 leads.
const cell = (v) => {
  const s = (v == null ? '' : String(v))
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u001F\u007F]+/g, " ")
    .replace(/\s{2,}/g, ' ')
    .trim();
  return /["\r\n,]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};

const q = (sql) => {
  const raw = execFileSync('npx', [
    'wrangler', 'd1', 'execute', DB, '--remote', '--json', '--command',
    sql.replace(/\s+/g, ' ').trim(),
  ], { cwd: HERE, maxBuffer: 512 * 1024 * 1024 }).toString();
  return JSON.parse(raw.slice(raw.indexOf('[')))[0].results;
};

mkdirSync(OUT, { recursive: true });

for (const dest of CITIES) {
  const lines = [COLS.join(',')];
  let offset = 0;
  process.stdout.write(`${dest}: `);

  for (;;) {
    // ORDER BY id, not rowid: a stable key is what makes paging safe. Without
    // it two pages can return the same row and a third can return none.
    const rows = q(`
      SELECT ${COLS.join(', ')}
        FROM places
       WHERE dest = '${dest}'
         AND ( (email IS NOT NULL AND email <> '')
            OR (phone IS NOT NULL AND phone <> '') )
       ORDER BY id
       LIMIT ${PAGE} OFFSET ${offset}`);
    if (!rows.length) break;
    for (const r of rows) lines.push(COLS.map((c) => cell(r[c])).join(','));
    offset += rows.length;
    process.stdout.write('.');
    if (rows.length < PAGE) break;
  }

  const path = OUT + `contacts-${dest}.csv`;
  writeFileSync(path, lines.join('\n') + '\n');
  console.log(` ${lines.length - 1} rows -> ${path}`);
}

// The summary covers everything, so the four sheets above are a selection and
// not a claim about what exists.
const totals = q(`
  SELECT dest,
         COUNT(*) places,
         SUM(CASE WHEN email   IS NOT NULL AND email   <> '' THEN 1 ELSE 0 END) with_email,
         SUM(CASE WHEN phone   IS NOT NULL AND phone   <> '' THEN 1 ELSE 0 END) with_phone,
         SUM(CASE WHEN website IS NOT NULL AND website <> '' THEN 1 ELSE 0 END) with_website,
         SUM(CASE WHEN (email IS NOT NULL AND email <> '')
                    OR (phone IS NOT NULL AND phone <> '') THEN 1 ELSE 0 END) reachable,
         SUM(CASE WHEN status = 'claimed' THEN 1 ELSE 0 END) claimed
    FROM places
   GROUP BY dest
   ORDER BY reachable DESC`);
const tCols = ['dest', 'places', 'with_email', 'with_phone', 'with_website', 'reachable', 'claimed'];
writeFileSync(
  OUT + 'contacts-summary.csv',
  [tCols.join(','), ...totals.map((r) => tCols.map((c) => cell(r[c])).join(','))].join('\n') + '\n',
);
console.log(`summary: ${totals.length} destinations -> ${OUT}contacts-summary.csv`);
