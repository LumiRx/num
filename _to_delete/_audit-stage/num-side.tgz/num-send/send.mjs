#!/usr/bin/env node
/**
 * The outreach sender. Resumable, self-pacing, and it refuses to do the one
 * thing that would cost you the domain.
 *
 *   RESEND_API_KEY=re_xxx node send.mjs --check      # verify, send nothing
 *   RESEND_API_KEY=re_xxx node send.mjs --today      # send today's allowance
 *   RESEND_API_KEY=re_xxx node send.mjs --today --city=edinburgh
 *
 * ── WHY IT WILL NOT SEND 14,784 IN ONE GO ────────────────────────────────
 *
 * itsnum.com has effectively no sending history. A domain that emits nothing
 * and then 14.8k in a day is not read by Gmail as a company with news; it is
 * read as a compromised domain, and the response is a block that applies to
 * EVERY message from it — including the password resets and booking
 * confirmations that the product depends on.
 *
 * So the ramp is enforced here rather than left to willpower. Day 1 is 50.
 * The whole list clears in about five weeks. Passing --force overrides the
 * cap for one run, which is in here because there will be a good reason one
 * day, and not because there is one today.
 *
 * ── STATE ────────────────────────────────────────────────────────────────
 *
 * ./state/sent.json records every address that has been sent to, with the day
 * and the Resend id. It is the resume point AND the deduplicator: an address
 * in there is never written to twice, whatever the CSVs say. Delete it and
 * you will mail 14,784 people a second time.
 */
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';

const HERE = new URL('.', import.meta.url).pathname;
const OUT = HERE + 'out/';
const STATE_DIR = HERE + 'state/';
const STATE = STATE_DIR + 'sent.json';
mkdirSync(STATE_DIR, { recursive: true });

const args = process.argv.slice(2);
const has = (f) => args.includes(f);
const val = (f) => (args.find((a) => a.startsWith(f + '=')) || '').split('=')[1] || '';

const KEY = process.env.RESEND_API_KEY || '';
const FROM = process.env.MAIL_FROM || 'NUM <info@itsnum.com>';
const REPLY = 'info@itsnum.com';

/* ── the ramp ───────────────────────────────────────────────────────────── */
// Day index (1-based, counted from the first send) → messages allowed that day.
const RAMP = [
  { untilDay: 7,  perDay: 50 },
  { untilDay: 14, perDay: 150 },
  { untilDay: 21, perDay: 400 },
  { untilDay: 28, perDay: 800 },
  { untilDay: 999, perDay: 1500 },
];
const allowanceFor = (day) => RAMP.find((r) => day <= r.untilDay).perDay;

/* ── subject lines, by variant, matching the CSV's `variant` column ─────── */
const SUBJECTS = {
  a: 'Your business is already on NUM',
  b: '{{business}} is listed on NUM and nobody has checked it',
  c: 'A quick note about your {{city}} listing',
  'th-a': 'ร้านของคุณอยู่บน NUM แล้ว',
  'th-b': '{{business}} อยู่บน NUM แต่ยังไม่มีใครตรวจสอบ',
  'th-c': 'เรื่องข้อมูลร้านของคุณในภูเก็ต',
};

const TEMPLATES = {
  en: { html: 'num-outreach-email.html', text: 'num-outreach-email.txt' },
  th: { html: 'num-outreach-email-th.html', text: 'num-outreach-email-th.txt' },
};
const TPL_DIR = process.env.TEMPLATE_DIR || HERE + 'templates/';

/* ── tiny CSV reader that respects quotes ──────────────────────────────── */
function parseCsv(text) {
  const rows = [];
  let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; }
      else if (c === '"') q = false;
      else cell += c;
    } else if (c === '"') q = true;
    else if (c === ',') { row.push(cell); cell = ''; }
    else if (c === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; }
    else if (c !== '\r') cell += c;
  }
  if (cell.length || row.length) { row.push(cell); rows.push(row); }
  const head = rows.shift();
  return rows.filter((r) => r.length === head.length && r[0])
             .map((r) => Object.fromEntries(head.map((h, i) => [h, r[i]])));
}

const fill = (s, r) =>
  s.replace(/\{\{(\w+)\}\}/g, (_, k) => r[k] ?? '');

/* ── load ───────────────────────────────────────────────────────────────── */
const state = existsSync(STATE) ? JSON.parse(readFileSync(STATE, 'utf8')) : { sent: {}, days: {} };
const alreadySent = new Set(Object.keys(state.sent));

let rows = [];
for (const f of readdirSync(OUT).filter((f) => f.endsWith('.csv'))) {
  if (val('--city') && !f.includes(val('--city'))) continue;
  rows.push(...parseCsv(readFileSync(OUT + f, 'utf8')));
}

// Edinburgh first: smallest, legally cleanest, cheapest place for a mistake.
// Then Los Angeles, then Phuket once a Thai speaker has read the copy.
const CITY_ORDER = ['Edinburgh', 'Los Angeles', 'Phuket'];
rows.sort((a, b) => CITY_ORDER.indexOf(a.city) - CITY_ORDER.indexOf(b.city));

const pending = rows.filter((r) => !alreadySent.has(r.email.toLowerCase()));

const today = new Date().toISOString().slice(0, 10);
const firstDay = Object.keys(state.days).sort()[0] || today;
const dayIndex = Math.floor((Date.parse(today) - Date.parse(firstDay)) / 86400000) + 1;
const allowance = allowanceFor(dayIndex);
const sentToday = state.days[today] || 0;
const remainingToday = Math.max(0, allowance - sentToday);

/* ── report ─────────────────────────────────────────────────────────────── */
console.log(`from            ${FROM}`);
console.log(`templates       ${TPL_DIR}`);
console.log(`rows loaded     ${rows.length}`);
console.log(`already sent    ${alreadySent.size}`);
console.log(`pending         ${pending.length}`);
console.log(`day ${dayIndex} of the ramp — allowance ${allowance}, sent today ${sentToday}, remaining ${remainingToday}`);
if (pending.length) {
  const byCity = {};
  for (const r of pending) byCity[r.city] = (byCity[r.city] || 0) + 1;
  console.log('next up         ' + Object.entries(byCity).map(([c, n]) => `${c} ${n}`).join(' · '));
}

/* ── preflight ──────────────────────────────────────────────────────────
 * The templates are loaded HERE, before --check returns, and not lazily just
 * before the send. The first run of this script reported "ready to send" and
 * then died on a missing template file the moment --today was added, which is
 * the exact opposite of what a check is for: a preflight that does not touch
 * the thing it is checking has not checked anything.
 */
const tpl = {};
let preflightOk = true;
for (const [lang, f] of Object.entries(TEMPLATES)) {
  try {
    tpl[lang] = {
      html: readFileSync(TPL_DIR + f.html, 'utf8'),
      text: readFileSync(TPL_DIR + f.text, 'utf8'),
    };
    console.log(`template ${lang}      ok (${f.html}, ${f.text})`);
  } catch (e) {
    preflightOk = false;
    console.error(`template ${lang}      MISSING — ${TPL_DIR}${f.html}`);
  }
}

// A merge tag left unfilled ships "{{business}}" to a stranger. Render one
// real row of each language and refuse if anything is still a placeholder.
if (preflightOk) {
  for (const lang of Object.keys(tpl)) {
    const row = rows.find((r) => r.language === lang);
    if (!row) continue;
    const filled = fill(tpl[lang].html, { ...row, unsubscribe_url: 'https://itsnum.com/stop/x' })
      + fill(SUBJECTS[row.variant] || '', row);
    const left = [...new Set(filled.match(/\{\{\w+\}\}/g) || [])];
    if (left.length) { preflightOk = false; console.error(`template ${lang}      UNFILLED ${left.join(' ')}`); }
    else console.log(`merge ${lang}         ok`);
  }
}

console.log(`resend key      ${KEY ? 'set' : 'NOT SET'}`);

if (!has('--today')) {
  console.log(preflightOk && KEY
    ? '\nReady. Add --today to send this day\'s allowance.'
    : '\nNOT ready — fix the lines above first.');
  // Exit code has to agree with the words. "NOT ready" over a zero exit is how
  // a check gets wired into a script that then proceeds anyway.
  process.exit(preflightOk && KEY ? 0 : 1);
}
if (!preflightOk) { console.error('\nPreflight failed. Nothing sent.'); process.exit(1); }
if (!KEY) { console.error('\nRESEND_API_KEY is not set. Nothing sent.'); process.exit(1); }

const batchSize = has('--force') ? pending.length : Math.min(remainingToday, pending.length);
if (!batchSize) { console.log('\nNothing to send right now.'); process.exit(0); }
if (has('--force')) {
  console.log('\n⚠  --force: ignoring the ramp. This is how a sending domain gets blocked,');
  console.log('   and itsnum.com also carries your password resets.');
}

/* ── send ───────────────────────────────────────────────────────────────── */
const batch = pending.slice(0, batchSize);
console.log(`\nSending ${batch.length}…`);

let ok = 0, failed = 0;
// Resend's batch endpoint takes 100 at a time.
for (let i = 0; i < batch.length; i += 100) {
  const chunk = batch.slice(i, i + 100);
  const payload = chunk.map((r) => {
    const t = tpl[r.language] || tpl.en;
    return {
      from: FROM,
      to: [r.email],
      reply_to: REPLY,
      subject: fill(SUBJECTS[r.variant] || SUBJECTS.a, r),
      html: fill(t.html, { ...r, unsubscribe_url: `https://itsnum.com/stop/${r.token}` }),
      text: fill(t.text, { ...r, unsubscribe_url: `https://itsnum.com/stop/${r.token}` }),
      headers: {
        // RFC 8058. Both parts, or Gmail does not show the one-click control.
        'List-Unsubscribe': `<https://itsnum.com/stop/${r.token}>, <mailto:info@itsnum.com?subject=unsubscribe>`,
        'List-Unsubscribe-Post': 'List-Unsubscribe=One-Click',
      },
    };
  });

  const res = await fetch('https://api.resend.com/emails/batch', {
    method: 'POST',
    headers: {
      authorization: 'Bearer ' + KEY,
      'content-type': 'application/json',
      // Same chunk twice must not mail the same people twice.
      'idempotency-key': createHash('sha256').update(chunk.map((r) => r.email).join(',')).digest('hex').slice(0, 32),
    },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    console.error(`  chunk ${i / 100 + 1}: HTTP ${res.status} ${(await res.text()).slice(0, 200)}`);
    failed += chunk.length;
    continue;
  }
  const body = await res.json().catch(() => ({}));
  (body.data || []).forEach((d, j) => {
    state.sent[chunk[j].email.toLowerCase()] = { id: d.id, day: today, city: chunk[j].city, variant: chunk[j].variant };
  });
  ok += chunk.length;
  process.stdout.write(`  ${ok}/${batch.length}\r`);
  // Written after every chunk, so a crash costs one chunk of bookkeeping and
  // never re-mails the ones that already went.
  state.days[today] = (state.days[today] || 0) + chunk.length;
  writeFileSync(STATE, JSON.stringify(state, null, 1));
  await new Promise((r) => setTimeout(r, 1200));
}

console.log(`\ndone — ${ok} sent, ${failed} failed`);
console.log(`state: ${STATE}`);
console.log('\nTomorrow: run the same command again. It picks up where this stopped.');
