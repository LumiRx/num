#!/usr/bin/env node
/**
 * Export the send-ready outreach lists, one CSV per city.
 *
 * Runs wrangler on this machine so 14,784 rows never travel through a chat
 * context. Each row already carries its merge values, its claim URL with the
 * right ?s= and utm tags, and its pixel token — so the sending tool has to do
 * nothing but fill {{...}} and send.
 *
 *   node export.mjs
 *
 * Language rule: country === 'TH' -> Thai template, English otherwise.
 * Keyed off COUNTRY, not destination, exactly as the claim receipt is.
 */
import { execFileSync } from 'node:child_process';
import { writeFileSync, mkdirSync } from 'node:fs';
import { createHash } from 'node:crypto';

const DB = 'num-db';
const HERE = new URL('.', import.meta.url).pathname;
const OUT = HERE + 'out/';
mkdirSync(OUT, { recursive: true });

/**
 * The per-recipient pixel token.
 *
 * A salted hash of the address, never the address itself. This value ends up
 * in a URL that gets forwarded, pasted into support tickets and logged by
 * every hop in between; an address in it is an address leaked. Salted so it
 * cannot be reversed by hashing a guessed address.
 *
 * Keep SEND_SALT stable or tokens from an earlier wave stop matching.
 */
const SALT = process.env.SEND_SALT || 'num-outreach-2026-08';
const tokenFor = (email) =>
  createHash('sha256').update(SALT + ':' + email.toLowerCase()).digest('hex').slice(0, 20);

const CITIES = [
  { dest: 'los-angeles', city: 'Los Angeles', landmark: 'the beach', cc: 'us',
    campaign: 'la-2026-08',  s: 'email-la-01' },
  { dest: 'edinburgh',   city: 'Edinburgh',   landmark: 'Old Town',  cc: 'gb',
    campaign: 'edi-2026-08', s: 'email-edi-01' },
  { dest: 'phuket',      city: 'Phuket',      landmark: 'old town',  cc: 'th',
    campaign: 'hkt-2026-08', s: 'email-hkt-01' },
];

const VARIANTS = ['a', 'b', 'c'];

/**
 * OSM business names contain things you would not expect a name to contain.
 *
 * The first export produced 7,488 rows for 7,487 Los Angeles leads: one name
 * carried a bare carriage return, the quoting test only looked for \n, so the
 * unquoted CR split that record across two lines and every column after it
 * shifted by one. A sending tool reading that file would have put a URL in
 * the language column and mailed somebody a blank.
 *
 * So: flatten every control character to a space first, then quote on any of
 * quote, comma, CR or LF. Newlines inside a name carry no meaning worth
 * keeping in a merge field.
 */
const csvCell = (v) => {
  const s = (v == null ? '' : String(v))
    // eslint-disable-next-line no-control-regex
    .replace(/[\u0000-\u001F\u007F]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
  return /["\r\n,]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
};

for (const c of CITIES) {
  const sql = `
    SELECT id, name, email, country, category
    FROM leads
    WHERE dest = '${c.dest}'
      AND email IS NOT NULL AND email <> ''
      AND lower(trim(email)) NOT IN (SELECT lower(email) FROM num_suppressions)
    ORDER BY id`.replace(/\s+/g, ' ').trim();

  process.stdout.write(`${c.dest}: querying... `);
  const raw = execFileSync('npx', [
    'wrangler', 'd1', 'execute', DB, '--remote', '--json', '--command', sql,
  ], { cwd: HERE, maxBuffer: 256 * 1024 * 1024 }).toString();

  const rows = JSON.parse(raw.slice(raw.indexOf('[')))[0].results;
  process.stdout.write(`${rows.length} rows\n`);

  const header = [
    'email', 'business', 'city', 'landmark', 'language', 'variant',
    'claim_url', 'campaign', 'token', 'category', 'lead_id',
  ];
  const lines = [header.join(',')];

  rows.forEach((r, i) => {
    // Thai iff the business is in Thailand. Everywhere else, English.
    const thai = String(r.country || '').toUpperCase() === 'TH';
    // Even split across the three subject lines, so the comparison is a
    // comparison and not an accident of ordering.
    const variant = VARIANTS[i % VARIANTS.length];
    const s = thai ? 'email-hkt-th-01' : c.s;
    // ?p= is the lead's own row id, and leads.id === places.id for all 93,250
    // rows (checked, not assumed). It is what makes the claim land bound to a
    // real listing — with coordinates, so it can be mapped and credited —
    // instead of as a business name in a text box. The claim page also has a
    // type-ahead for anyone arriving cold, but that is a search; this is exact.
    const url =
      `https://itsnum.com/claim/?c=${c.cc}` +
      `&p=${encodeURIComponent(r.id)}` +
      // The name too, so the page opens saying "Confirm your listing for X"
      // with the field already filled, and can show what the ?p= above bound
      // it to. Without it the page tells a business we already emailed by name
      // that we could not read their name from the link, which is nonsense on
      // its face and reads as a template that was never checked.
      `&b=${encodeURIComponent(r.name)}` +
      (thai ? '&lang=th' : '') +
      `&d=${c.dest}&s=${s}` +
      `&utm_source=email&utm_medium=outreach&utm_campaign=${c.campaign}` +
      `&utm_content=${thai ? 'th-' : ''}${variant}`;

    lines.push([
      r.email, r.name, c.city, c.landmark,
      thai ? 'th' : 'en',
      (thai ? 'th-' : '') + variant,
      url, c.campaign, tokenFor(r.email), r.category, r.id,
    ].map(csvCell).join(','));
  });

  const path = OUT + `num-outreach-${c.dest}.csv`;
  writeFileSync(path, lines.join('\n') + '\n');
  console.log(`  -> ${path}`);
}

console.log('\nDone. One CSV per city in ./out/.');
console.log('The `language` column decides the template: th or en.');
